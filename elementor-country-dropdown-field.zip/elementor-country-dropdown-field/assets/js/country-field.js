(() => {
	'use strict';

	const FIELD_SELECTOR = '[data-ecdf-country-field]';

	function closeField(field) {
		const trigger = field.querySelector('[data-ecdf-role="trigger"]');

		field.classList.remove('is-open');

		if (trigger) {
			trigger.setAttribute('aria-expanded', 'false');
		}
	}

	function closeAllFields(exceptField = null) {
		document.querySelectorAll(FIELD_SELECTOR + '.is-open').forEach((field) => {
			if (field !== exceptField) {
				closeField(field);
			}
		});
	}

	function flagEmoji(countryCode) {
		if (!countryCode) {
			return '';
		}

		return [...countryCode.toUpperCase()]
			.map((character) => String.fromCodePoint(127397 + character.charCodeAt(0)))
			.join('');
	}

	function updateSelectedDisplay(field, select, selectedContainer) {
		const selectedOption = select.options[select.selectedIndex];

		if (!selectedOption || !select.value) {
			const placeholderText = select.options[0] ? select.options[0].textContent : 'Select Country';
			selectedContainer.innerHTML = `<span class="ecdf-country-placeholder">${escapeHtml(placeholderText)}</span>`;
			return;
		}

		const countryName = selectedOption.textContent || select.value;
		const countryCode = selectedOption.dataset.code || '';
		const flag = flagEmoji(countryCode);

		selectedContainer.innerHTML = `
			<span class="ecdf-country-flag" aria-hidden="true">${escapeHtml(flag)}</span>
			<span class="ecdf-country-name">${escapeHtml(countryName)}</span>
		`;
	}

	function setSelectedOption(field, select, selectedContainer, optionButton) {
		const value = optionButton.dataset.name || '';

		select.value = value;
		select.dispatchEvent(new Event('input', { bubbles: true }));
		select.dispatchEvent(new Event('change', { bubbles: true }));

		field.querySelectorAll('.ecdf-country-option').forEach((button) => {
			const isSelected = button === optionButton;
			button.classList.toggle('is-selected', isSelected);
			button.setAttribute('aria-selected', isSelected ? 'true' : 'false');
		});

		updateSelectedDisplay(field, select, selectedContainer);
		closeField(field);
	}

	function syncSelectedOption(field, select, selectedContainer) {
		const activeValue = select.value;

		field.querySelectorAll('.ecdf-country-option').forEach((button) => {
			const isSelected = button.dataset.name === activeValue;
			button.classList.toggle('is-selected', isSelected);
			button.setAttribute('aria-selected', isSelected ? 'true' : 'false');
		});

		updateSelectedDisplay(field, select, selectedContainer);
	}

	function escapeHtml(value) {
		return String(value)
			.replaceAll('&', '&amp;')
			.replaceAll('<', '&lt;')
			.replaceAll('>', '&gt;')
			.replaceAll('"', '&quot;')
			.replaceAll("'", '&#039;');
	}

	function initCountryField(field) {
		if (!field || field.dataset.ecdfInitialized === 'true') {
			return;
		}

		const select = field.querySelector('[data-ecdf-role="native"]');
		const trigger = field.querySelector('[data-ecdf-role="trigger"]');
		const panel = field.querySelector('[data-ecdf-role="panel"]');
		const selectedContainer = field.querySelector('[data-ecdf-role="selected"]');

		if (!select || !trigger || !panel || !selectedContainer) {
			return;
		}

		field.dataset.ecdfInitialized = 'true';

		syncSelectedOption(field, select, selectedContainer);

		trigger.addEventListener('click', () => {
			const willOpen = !field.classList.contains('is-open');

			closeAllFields(field);
			field.classList.toggle('is-open', willOpen);
			trigger.setAttribute('aria-expanded', willOpen ? 'true' : 'false');

			if (willOpen) {
				const currentOption = field.querySelector('.ecdf-country-option.is-selected');
				if (currentOption) {
					currentOption.scrollIntoView({ block: 'nearest' });
				}
			}
		});

		field.querySelectorAll('.ecdf-country-option').forEach((optionButton) => {
			optionButton.addEventListener('click', () => {
				setSelectedOption(field, select, selectedContainer, optionButton);
				trigger.focus();
			});
		});

		select.addEventListener('change', () => {
			syncSelectedOption(field, select, selectedContainer);
		});

		trigger.addEventListener('keydown', (event) => {
			if (event.key === 'ArrowDown' || event.key === 'Enter' || event.key === ' ') {
				event.preventDefault();
				if (!field.classList.contains('is-open')) {
					trigger.click();
				}

				const firstOption = field.querySelector('.ecdf-country-option');
				if (firstOption) {
					firstOption.focus();
				}
			}
		});

		panel.addEventListener('keydown', (event) => {
			const focusedOption = document.activeElement.closest('.ecdf-country-option');

			if (event.key === 'Escape') {
				event.preventDefault();
				closeField(field);
				trigger.focus();
				return;
			}

			if (!focusedOption) {
				return;
			}

			if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
				event.preventDefault();

				const options = Array.from(field.querySelectorAll('.ecdf-country-option'));
				const currentIndex = options.indexOf(focusedOption);
				const nextIndex = event.key === 'ArrowDown'
					? Math.min(currentIndex + 1, options.length - 1)
					: Math.max(currentIndex - 1, 0);

				options[nextIndex].focus();
			}
		});

		const form = field.closest('form');

		if (form) {
			form.addEventListener('reset', () => {
				window.setTimeout(() => {
					syncSelectedOption(field, select, selectedContainer);
					closeField(field);
				}, 0);
			});
		}
	}

	function initAllCountryFields(scope = document) {
		scope.querySelectorAll(FIELD_SELECTOR).forEach(initCountryField);
	}

	document.addEventListener('DOMContentLoaded', () => {
		initAllCountryFields(document);
	});

	document.addEventListener('click', (event) => {
		if (!event.target.closest(FIELD_SELECTOR)) {
			closeAllFields();
		}
	});

	document.addEventListener('keydown', (event) => {
		if (event.key === 'Escape') {
			closeAllFields();
		}
	});

	window.addEventListener('elementor/frontend/init', () => {
		if (!window.elementorFrontend || !window.elementorFrontend.hooks) {
			return;
		}

		window.elementorFrontend.hooks.addAction('frontend/element_ready/form.default', ($scope) => {
			const root = $scope && $scope[0] ? $scope[0] : document;
			initAllCountryFields(root);
		});
	});
})();
