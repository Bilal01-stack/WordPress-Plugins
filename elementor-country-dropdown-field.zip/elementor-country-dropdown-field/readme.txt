=== Elementor Country Dropdown Field ===
Contributors: Morosoft Custom
Tags: Elementor, Elementor Pro, forms, country dropdown
Requires at least: 6.0
Tested up to: 6.9
Stable tag: 1.0.0
License: GPLv2 or later

Adds one custom field type to Elementor Pro Forms:
Country Dropdown

== What it does ==
- Adds "Country Dropdown" inside Elementor Form > Field Type
- Shows a clickable country field on the frontend
- Opens a scrollable dropdown with country flags and names
- Sends the selected country value with Elementor form submissions
- Supports Elementor's existing Label, Placeholder, and Required settings

== Installation ==
1. WordPress Dashboard > Plugins > Add New > Upload Plugin
2. Upload this ZIP file
3. Activate the plugin
4. Edit the page with Elementor
5. Open your Form widget
6. Add a field or edit your current country field
7. Set Type to "Country Dropdown"
8. Set Label as Country and Placeholder as Select Country
9. Update the page

Requires Elementor Pro Forms.
