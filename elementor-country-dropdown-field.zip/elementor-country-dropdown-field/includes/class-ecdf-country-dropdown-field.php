<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor Pro Forms field: Country Dropdown.
 */
class ECDF_Country_Dropdown_Field extends \ElementorPro\Modules\Forms\Fields\Field_Base {

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct();
		add_action( 'elementor/preview/init', [ $this, 'editor_preview_footer' ] );
	}

	/**
	 * Unique Elementor field type slug.
	 *
	 * @return string
	 */
	public function get_type(): string {
		return 'country-dropdown';
	}

	/**
	 * Field label shown inside the Elementor Form "Type" dropdown.
	 *
	 * @return string
	 */
	public function get_name(): string {
		return esc_html__( 'Country Dropdown', 'elementor-country-dropdown-field' );
	}

	/**
	 * Frontend JS dependency.
	 *
	 * @return array
	 */
	public function get_script_depends(): array {
		return [ 'ecdf-country-field' ];
	}

	/**
	 * Frontend CSS dependency.
	 *
	 * @return array
	 */
	public function get_style_depends(): array {
		return [ 'ecdf-country-field' ];
	}

	/**
	 * Render the field HTML.
	 *
	 * @param array $item Field settings.
	 * @param int   $item_index Field index.
	 * @param mixed $form Elementor form widget instance.
	 * @return void
	 */
	public function render( $item, $item_index, $form ): void {
		$countries   = self::get_countries();
		$placeholder = ! empty( $item['placeholder'] )
			? (string) $item['placeholder']
			: esc_html__( 'Select Country', 'elementor-country-dropdown-field' );

		$default_value = '';
		foreach ( [ 'field_value', 'default_value', 'value' ] as $possible_key ) {
			if ( isset( $item[ $possible_key ] ) && '' !== (string) $item[ $possible_key ] ) {
				$default_value = trim( (string) $item[ $possible_key ] );
				break;
			}
		}

		$form->add_render_attribute(
			'input' . $item_index,
			[
				'class'           => [
					'ecdf-country-native',
					'elementor-field',
					'elementor-field-textual',
				],
				'data-ecdf-role'  => 'native',
				'aria-label'      => $placeholder,
			]
		);

		echo '<div class="ecdf-country-field" data-ecdf-country-field>';

		echo '<select ' . $form->get_render_attribute_string( 'input' . $item_index ) . '>';
		echo '<option value="">' . esc_html( $placeholder ) . '</option>';

		foreach ( $countries as $code => $name ) {
			$is_selected = ( $default_value === $name || strtoupper( $default_value ) === $code );
			printf(
				'<option value="%1$s" data-code="%2$s"%3$s>%4$s</option>',
				esc_attr( $name ),
				esc_attr( $code ),
				selected( $is_selected, true, false ),
				esc_html( $name )
			);
		}

		echo '</select>';

		echo '<button type="button" class="ecdf-country-trigger elementor-field elementor-field-textual" data-ecdf-role="trigger" aria-haspopup="listbox" aria-expanded="false">';
		echo '<span class="ecdf-country-selected" data-ecdf-role="selected">';
		echo '<span class="ecdf-country-placeholder">' . esc_html( $placeholder ) . '</span>';
		echo '</span>';
		echo '<span class="ecdf-country-chevron" aria-hidden="true"></span>';
		echo '</button>';

		echo '<div class="ecdf-country-panel" data-ecdf-role="panel" role="listbox" tabindex="-1">';

		foreach ( $countries as $code => $name ) {
			printf(
				'<button type="button" class="ecdf-country-option" role="option" data-code="%1$s" data-name="%2$s" aria-selected="false"><span class="ecdf-country-flag" aria-hidden="true">%3$s</span><span class="ecdf-country-name">%4$s</span></button>',
				esc_attr( $code ),
				esc_attr( $name ),
				esc_html( self::get_flag_emoji( $code ) ),
				esc_html( $name )
			);
		}

		echo '</div>';
		echo '</div>';
	}

	/**
	 * Validate submitted value.
	 *
	 * @param array                                                        $field Submitted field data.
	 * @param \ElementorPro\Modules\Forms\Classes\Form_Record            $record Form record.
	 * @param \ElementorPro\Modules\Forms\Classes\Ajax_Handler           $ajax_handler AJAX handler.
	 * @return void
	 */
	public function validation( $field, $record, $ajax_handler ): void {
		$value = isset( $field['value'] ) ? trim( (string) $field['value'] ) : '';

		if ( ! empty( $field['required'] ) && '' === $value ) {
			$ajax_handler->add_error(
				$field['id'],
				esc_html__( 'Please select a country.', 'elementor-country-dropdown-field' )
			);
			return;
		}

		if ( '' === $value ) {
			return;
		}

		$valid_country_names = array_values( self::get_countries() );

		if ( ! in_array( $value, $valid_country_names, true ) ) {
			$ajax_handler->add_error(
				$field['id'],
				esc_html__( 'Please choose a valid country from the list.', 'elementor-country-dropdown-field' )
			);
		}
	}

	/**
	 * Register an editor preview template so the field appears immediately in Elementor editor.
	 *
	 * @return void
	 */
	public function editor_preview_footer(): void {
		add_action( 'wp_footer', [ $this, 'content_template_script' ] );
	}

	/**
	 * Elementor editor preview template.
	 *
	 * @return void
	 */
	public function content_template_script(): void {
		?>
		<script>
			jQuery( document ).ready( () => {
				elementor.hooks.addFilter(
					'elementor_pro/forms/content_template/field/<?php echo esc_js( $this->get_type() ); ?>',
					function( inputField, item ) {
						const placeholder = item.placeholder || '<?php echo esc_js( esc_html__( 'Select Country', 'elementor-country-dropdown-field' ) ); ?>';

						return `
							<div class="ecdf-country-field ecdf-country-field--preview">
								<button type="button" class="ecdf-country-trigger elementor-field elementor-field-textual" disabled>
									<span class="ecdf-country-selected">
										<span class="ecdf-country-placeholder">${ _.escape( placeholder ) }</span>
									</span>
									<span class="ecdf-country-chevron" aria-hidden="true"></span>
								</button>
							</div>
						`;
					},
					10,
					3
				);
			});
		</script>
		<?php
	}

	/**
	 * Return the complete country/territory list.
	 *
	 * @return array<string,string>
	 */
	private static function get_countries(): array {
		return [
			'AF' => 'Afghanistan',
			'AL' => 'Albania',
			'DZ' => 'Algeria',
			'AS' => 'American Samoa',
			'AD' => 'Andorra',
			'AO' => 'Angola',
			'AI' => 'Anguilla',
			'AQ' => 'Antarctica',
			'AG' => 'Antigua and Barbuda',
			'AR' => 'Argentina',
			'AM' => 'Armenia',
			'AW' => 'Aruba',
			'AU' => 'Australia',
			'AT' => 'Austria',
			'AZ' => 'Azerbaijan',
			'BS' => 'Bahamas',
			'BH' => 'Bahrain',
			'BD' => 'Bangladesh',
			'BB' => 'Barbados',
			'BY' => 'Belarus',
			'BE' => 'Belgium',
			'BZ' => 'Belize',
			'BJ' => 'Benin',
			'BM' => 'Bermuda',
			'BT' => 'Bhutan',
			'BO' => 'Bolivia',
			'BQ' => 'Bonaire, Sint Eustatius and Saba',
			'BA' => 'Bosnia and Herzegovina',
			'BW' => 'Botswana',
			'BV' => 'Bouvet Island',
			'BR' => 'Brazil',
			'IO' => 'British Indian Ocean Territory',
			'VG' => 'British Virgin Islands',
			'BN' => 'Brunei',
			'BG' => 'Bulgaria',
			'BF' => 'Burkina Faso',
			'BI' => 'Burundi',
			'CV' => 'Cabo Verde',
			'KH' => 'Cambodia',
			'CM' => 'Cameroon',
			'CA' => 'Canada',
			'KY' => 'Cayman Islands',
			'CF' => 'Central African Republic',
			'TD' => 'Chad',
			'CL' => 'Chile',
			'CN' => 'China',
			'CX' => 'Christmas Island',
			'CC' => 'Cocos (Keeling) Islands',
			'CO' => 'Colombia',
			'KM' => 'Comoros',
			'CK' => 'Cook Islands',
			'CR' => 'Costa Rica',
			'HR' => 'Croatia',
			'CU' => 'Cuba',
			'CW' => 'Curaçao',
			'CY' => 'Cyprus',
			'CZ' => 'Czechia',
			'CI' => 'Côte d\'Ivoire',
			'CD' => 'Democratic Republic of the Congo',
			'DK' => 'Denmark',
			'DJ' => 'Djibouti',
			'DM' => 'Dominica',
			'DO' => 'Dominican Republic',
			'EC' => 'Ecuador',
			'EG' => 'Egypt',
			'SV' => 'El Salvador',
			'GQ' => 'Equatorial Guinea',
			'ER' => 'Eritrea',
			'EE' => 'Estonia',
			'SZ' => 'Eswatini',
			'ET' => 'Ethiopia',
			'FK' => 'Falkland Islands',
			'FO' => 'Faroe Islands',
			'FJ' => 'Fiji',
			'FI' => 'Finland',
			'FR' => 'France',
			'GF' => 'French Guiana',
			'PF' => 'French Polynesia',
			'TF' => 'French Southern Territories',
			'GA' => 'Gabon',
			'GM' => 'Gambia',
			'GE' => 'Georgia',
			'DE' => 'Germany',
			'GH' => 'Ghana',
			'GI' => 'Gibraltar',
			'GR' => 'Greece',
			'GL' => 'Greenland',
			'GD' => 'Grenada',
			'GP' => 'Guadeloupe',
			'GU' => 'Guam',
			'GT' => 'Guatemala',
			'GG' => 'Guernsey',
			'GN' => 'Guinea',
			'GW' => 'Guinea-Bissau',
			'GY' => 'Guyana',
			'HT' => 'Haiti',
			'HM' => 'Heard Island and McDonald Islands',
			'VA' => 'Holy See (Vatican City State)',
			'HN' => 'Honduras',
			'HK' => 'Hong Kong',
			'HU' => 'Hungary',
			'IS' => 'Iceland',
			'IN' => 'India',
			'ID' => 'Indonesia',
			'IR' => 'Iran',
			'IQ' => 'Iraq',
			'IE' => 'Ireland',
			'IM' => 'Isle of Man',
			'IL' => 'Israel',
			'IT' => 'Italy',
			'JM' => 'Jamaica',
			'JP' => 'Japan',
			'JE' => 'Jersey',
			'JO' => 'Jordan',
			'KZ' => 'Kazakhstan',
			'KE' => 'Kenya',
			'KI' => 'Kiribati',
			'KW' => 'Kuwait',
			'KG' => 'Kyrgyzstan',
			'LA' => 'Laos',
			'LV' => 'Latvia',
			'LB' => 'Lebanon',
			'LS' => 'Lesotho',
			'LR' => 'Liberia',
			'LY' => 'Libya',
			'LI' => 'Liechtenstein',
			'LT' => 'Lithuania',
			'LU' => 'Luxembourg',
			'MO' => 'Macao',
			'MG' => 'Madagascar',
			'MW' => 'Malawi',
			'MY' => 'Malaysia',
			'MV' => 'Maldives',
			'ML' => 'Mali',
			'MT' => 'Malta',
			'MH' => 'Marshall Islands',
			'MQ' => 'Martinique',
			'MR' => 'Mauritania',
			'MU' => 'Mauritius',
			'YT' => 'Mayotte',
			'MX' => 'Mexico',
			'FM' => 'Micronesia',
			'MD' => 'Moldova',
			'MC' => 'Monaco',
			'MN' => 'Mongolia',
			'ME' => 'Montenegro',
			'MS' => 'Montserrat',
			'MA' => 'Morocco',
			'MZ' => 'Mozambique',
			'MM' => 'Myanmar',
			'NA' => 'Namibia',
			'NR' => 'Nauru',
			'NP' => 'Nepal',
			'NL' => 'Netherlands',
			'NC' => 'New Caledonia',
			'NZ' => 'New Zealand',
			'NI' => 'Nicaragua',
			'NE' => 'Niger',
			'NG' => 'Nigeria',
			'NU' => 'Niue',
			'NF' => 'Norfolk Island',
			'KP' => 'North Korea',
			'MK' => 'North Macedonia',
			'MP' => 'Northern Mariana Islands',
			'NO' => 'Norway',
			'OM' => 'Oman',
			'PK' => 'Pakistan',
			'PW' => 'Palau',
			'PS' => 'Palestine',
			'PA' => 'Panama',
			'PG' => 'Papua New Guinea',
			'PY' => 'Paraguay',
			'PE' => 'Peru',
			'PH' => 'Philippines',
			'PN' => 'Pitcairn',
			'PL' => 'Poland',
			'PT' => 'Portugal',
			'PR' => 'Puerto Rico',
			'QA' => 'Qatar',
			'CG' => 'Republic of the Congo',
			'RO' => 'Romania',
			'RU' => 'Russia',
			'RW' => 'Rwanda',
			'RE' => 'Réunion',
			'BL' => 'Saint Barthélemy',
			'SH' => 'Saint Helena, Ascension and Tristan da Cunha',
			'KN' => 'Saint Kitts and Nevis',
			'LC' => 'Saint Lucia',
			'MF' => 'Saint Martin (French part)',
			'PM' => 'Saint Pierre and Miquelon',
			'VC' => 'Saint Vincent and the Grenadines',
			'WS' => 'Samoa',
			'SM' => 'San Marino',
			'ST' => 'Sao Tome and Principe',
			'SA' => 'Saudi Arabia',
			'SN' => 'Senegal',
			'RS' => 'Serbia',
			'SC' => 'Seychelles',
			'SL' => 'Sierra Leone',
			'SG' => 'Singapore',
			'SX' => 'Sint Maarten (Dutch part)',
			'SK' => 'Slovakia',
			'SI' => 'Slovenia',
			'SB' => 'Solomon Islands',
			'SO' => 'Somalia',
			'ZA' => 'South Africa',
			'GS' => 'South Georgia and the South Sandwich Islands',
			'KR' => 'South Korea',
			'SS' => 'South Sudan',
			'ES' => 'Spain',
			'LK' => 'Sri Lanka',
			'SD' => 'Sudan',
			'SR' => 'Suriname',
			'SJ' => 'Svalbard and Jan Mayen',
			'SE' => 'Sweden',
			'CH' => 'Switzerland',
			'SY' => 'Syria',
			'TW' => 'Taiwan',
			'TJ' => 'Tajikistan',
			'TZ' => 'Tanzania',
			'TH' => 'Thailand',
			'TL' => 'Timor-Leste',
			'TG' => 'Togo',
			'TK' => 'Tokelau',
			'TO' => 'Tonga',
			'TT' => 'Trinidad and Tobago',
			'TN' => 'Tunisia',
			'TM' => 'Turkmenistan',
			'TC' => 'Turks and Caicos Islands',
			'TV' => 'Tuvalu',
			'TR' => 'Türkiye',
			'VI' => 'U.S. Virgin Islands',
			'UG' => 'Uganda',
			'UA' => 'Ukraine',
			'AE' => 'United Arab Emirates',
			'GB' => 'United Kingdom',
			'US' => 'United States',
			'UM' => 'United States Minor Outlying Islands',
			'UY' => 'Uruguay',
			'UZ' => 'Uzbekistan',
			'VU' => 'Vanuatu',
			'VE' => 'Venezuela',
			'VN' => 'Vietnam',
			'WF' => 'Wallis and Futuna',
			'EH' => 'Western Sahara',
			'YE' => 'Yemen',
			'ZM' => 'Zambia',
			'ZW' => 'Zimbabwe',
			'AX' => 'Åland Islands',
		];
	}

	/**
	 * Convert ISO-2 country code into a flag emoji.
	 *
	 * @param string $country_code ISO alpha-2 country code.
	 * @return string
	 */
	private static function get_flag_emoji( string $country_code ): string {
		$country_code = strtoupper( $country_code );
		$flag         = '';

		foreach ( str_split( $country_code ) as $letter ) {
			$flag .= html_entity_decode( '&#x' . dechex( 127397 + ord( $letter ) ) . ';', ENT_NOQUOTES, 'UTF-8' );
		}

		return $flag;
	}
}
