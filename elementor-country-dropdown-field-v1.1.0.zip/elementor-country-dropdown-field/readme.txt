=== Elementor Country Dropdown Field ===
Contributors: Morosoft Custom
Tags: Elementor, Elementor Pro, forms, country dropdown, mobile country code
Requires at least: 6.0
Tested up to: 6.9
Stable tag: 1.1.0
License: GPLv2 or later

Adds two custom field types to Elementor Pro Forms:
1. Country Dropdown
2. Mobile Number + Country Code

== What it does ==
- Adds "Country Dropdown" inside Elementor Form > Field Type
- Adds "Mobile Number + Country Code" inside Elementor Form > Field Type
- Adds search inside both dropdown lists so users can type and quickly find countries
- Shows country flags, names, and calling codes
- Automatically syncs the Country Dropdown and Mobile Number country code inside the same form
- If a mismatch is forced, form validation blocks submission
- Sends the mobile value in a clean format such as +92 3001234567
- Supports Elementor's existing Label, Placeholder, and Required settings

== Installation ==
1. WordPress Dashboard > Plugins > Add New > Upload Plugin
2. Upload this ZIP file
3. Activate the plugin
4. Edit the page with Elementor
5. Open your Form widget
6. Add or edit the country field and set Type to "Country Dropdown"
7. Add a phone field and set Type to "Mobile Number + Country Code"
8. Set labels/placeholders as needed
9. Update the page

Requires Elementor Pro Forms.
