<?php
/**
 * Plugin Name: Elementor Country Dropdown Field
 * Description: Adds searchable Country Dropdown and Mobile Number + Country Code fields to Elementor Pro Forms, with same-country syncing and validation.
 * Version: 1.1.0
 * Author: Morosoft Custom
 * Text Domain: elementor-country-dropdown-field
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ECDF_VERSION', '1.1.0' );
define( 'ECDF_PLUGIN_FILE', __FILE__ );
define( 'ECDF_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'ECDF_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Register the CSS/JS used by the custom country field.
 * Elementor enqueues them only when the field is present on the page.
 *
 * @return void
 */
function ecdf_register_country_field_assets(): void {
	wp_register_style(
		'ecdf-country-field',
		ECDF_PLUGIN_URL . 'assets/css/country-field.css',
		[],
		ECDF_VERSION
	);

	wp_register_script(
		'ecdf-country-field',
		ECDF_PLUGIN_URL . 'assets/js/country-field.js',
		[],
		ECDF_VERSION,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'ecdf_register_country_field_assets' );
add_action( 'elementor/editor/after_enqueue_scripts', 'ecdf_register_country_field_assets' );

/**
 * Register the Elementor Pro Form field type.
 *
 * @param \ElementorPro\Modules\Forms\Registrars\Form_Fields_Registrar $form_fields_registrar Registrar instance.
 * @return void
 */
function ecdf_register_country_dropdown_field( $form_fields_registrar ): void {
	if ( ! class_exists( '\ElementorPro\Modules\Forms\Fields\Field_Base' ) ) {
		return;
	}

	require_once ECDF_PLUGIN_PATH . 'includes/class-ecdf-country-dropdown-field.php';
	require_once ECDF_PLUGIN_PATH . 'includes/class-ecdf-mobile-country-field.php';

	$form_fields_registrar->register( new \ECDF_Country_Dropdown_Field() );
	$form_fields_registrar->register( new \ECDF_Mobile_Country_Field() );
}
add_action( 'elementor_pro/forms/fields/register', 'ecdf_register_country_dropdown_field' );

/**
 * Small admin notice when Elementor Pro Forms is not available.
 *
 * @return void
 */
function ecdf_country_field_missing_elementor_pro_notice(): void {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	if ( class_exists( '\ElementorPro\Modules\Forms\Fields\Field_Base' ) ) {
		return;
	}

	echo '<div class="notice notice-warning"><p>';
	echo esc_html__( 'Elementor Country Dropdown Field requires Elementor Pro Forms to be active.', 'elementor-country-dropdown-field' );
	echo '</p></div>';
}
add_action( 'admin_notices', 'ecdf_country_field_missing_elementor_pro_notice' );
