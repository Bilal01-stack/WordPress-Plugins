(() => {
	'use strict';

	const COUNTRY_FIELD_SELECTOR = '[data-ecdf-country-field]';
	const MOBILE_FIELD_SELECTOR = '[data-ecdf-mobile-field]';

	function escapeHtml(value) {
		return String(value)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#039;');
	}

	function normalizeSearch(value) {
		return String(value || '')
			.normalize('NFD')
			.replace(/[\u0300-\u036f]/g, '')
			.toLowerCase()
			.trim();
	}

	function flagEmoji(countryCode) {
		if (!countryCode) {
			return '';
		}

		return [...countryCode.toUpperCase()]
			.map((character) => String.fromCodePoint(127397 + character.charCodeAt(0)))
			.join('');
	}

	function getVisibleOptions(panel, selector) {
		return Array.from(panel.querySelectorAll(selector)).filter((option) => !option.hidden);
	}

	function findOptionByCountryCode(root, selector, countryCode) {
		return Array.from(root.querySelectorAll(selector)).find((option) => option.dataset.code === countryCode) || null;
	}

	function filterPanelOptions(panel, searchInput, selector) {
		const query = normalizeSearch(searchInput ? searchInput.value : '');

		panel.querySelectorAll(selector).forEach((option) => {
			const haystack = normalizeSearch(option.dataset.search || option.textContent || '');
			option.hidden = Boolean(query) && !haystack.includes(query);
		});
	}

	function resetPanelFilter(panel, searchInput, selector) {
		if (searchInput) {
			searchInput.value = '';
		}

		panel.querySelectorAll(selector).forEach((option) => {
			option.hidden = false;
		});
	}

	function closeCountryField(field) {
		const trigger = field.querySelector('[data-ecdf-role="trigger"]');
		const panel = field.querySelector('[data-ecdf-role="panel"]');
		const searchInput = field.querySelector('[data-ecdf-role="country-search"]');

		field.classList.remove('is-open');

		if (trigger) {
			trigger.setAttribute('aria-expanded', 'false');
		}

		if (panel) {
			resetPanelFilter(panel, searchInput, '.ecdf-country-option');
		}
	}

	function closeAllCountryFields(exceptField = null) {
		document.querySelectorAll(COUNTRY_FIELD_SELECTOR + '.is-open').forEach((field) => {
			if (field !== exceptField) {
				closeCountryField(field);
			}
		});
	}

	function updateCountrySelectedDisplay(select, selectedContainer) {
		const selectedOption = select.options[select.selectedIndex];

		if (!selectedOption || !select.value) {
			const placeholderText = select.options[0] ? select.options[0].textContent : 'Select Country';
			selectedContainer.innerHTML = `<span class="ecdf-country-placeholder">${escapeHtml(placeholderText)}</span>`;
			return;
		}

		const countryName = selectedOption.textContent || select.value;
		const countryCode = selectedOption.dataset.code || '';
		const flag = flagEmoji(countryCode);

		selectedContainer.innerHTML = `
			<span class="ecdf-country-flag" aria-hidden="true">${escapeHtml(flag)}</span>
			<span class="ecdf-country-name">${escapeHtml(countryName)}</span>
		`;
	}

	function syncCountrySelectedOption(field, select, selectedContainer) {
		const activeValue = select.value;

		field.querySelectorAll('.ecdf-country-option').forEach((button) => {
			const isSelected = button.dataset.name === activeValue;
			button.classList.toggle('is-selected', isSelected);
			button.setAttribute('aria-selected', isSelected ? 'true' : 'false');
		});

		updateCountrySelectedDisplay(select, selectedContainer);
	}

	function notifyCountryChanged(field, select) {
		const selectedOption = select.options[select.selectedIndex];
		const form = field.closest('form');

		if (!form || !selectedOption || !select.value) {
			return;
		}

		form.dispatchEvent(new CustomEvent('ecdf:country-change', {
			detail: {
				code: selectedOption.dataset.code || '',
				name: selectedOption.textContent || select.value,
			},
		}));
	}

	function setCountrySelectedOption(field, select, optionButton) {
		const value = optionButton.dataset.name || '';

		select.value = value;
		select.dispatchEvent(new Event('input', { bubbles: true }));
		select.dispatchEvent(new Event('change', { bubbles: true }));

		closeCountryField(field);
	}

	function initCountryField(field) {
		if (!field || field.dataset.ecdfInitialized === 'true') {
			return;
		}

		const select = field.querySelector('[data-ecdf-role="native"]');
		const trigger = field.querySelector('[data-ecdf-role="trigger"]');
		const panel = field.querySelector('[data-ecdf-role="panel"]');
		const selectedContainer = field.querySelector('[data-ecdf-role="selected"]');
		const searchInput = field.querySelector('[data-ecdf-role="country-search"]');

		if (!select || !trigger || !panel || !selectedContainer) {
			return;
		}

		field.dataset.ecdfInitialized = 'true';
		syncCountrySelectedOption(field, select, selectedContainer);

		trigger.addEventListener('click', () => {
			const willOpen = !field.classList.contains('is-open');

			closeAllCountryFields(field);
			closeAllMobileFields();
			field.classList.toggle('is-open', willOpen);
			trigger.setAttribute('aria-expanded', willOpen ? 'true' : 'false');

			if (willOpen) {
				window.setTimeout(() => {
					if (searchInput) {
						searchInput.focus();
						return;
					}

					const currentOption = field.querySelector('.ecdf-country-option.is-selected');
					if (currentOption) {
						currentOption.scrollIntoView({ block: 'nearest' });
					}
				}, 0);
			}
		});

		field.querySelectorAll('.ecdf-country-option').forEach((optionButton) => {
			optionButton.addEventListener('click', () => {
				setCountrySelectedOption(field, select, optionButton);
				trigger.focus();
			});
		});

		select.addEventListener('change', () => {
			syncCountrySelectedOption(field, select, selectedContainer);
			notifyCountryChanged(field, select);
		});

		trigger.addEventListener('keydown', (event) => {
			if (event.key === 'ArrowDown' || event.key === 'Enter' || event.key === ' ') {
				event.preventDefault();

				if (!field.classList.contains('is-open')) {
					trigger.click();
				}

				if (searchInput) {
					searchInput.focus();
					return;
				}

				const firstOption = getVisibleOptions(panel, '.ecdf-country-option')[0];
				if (firstOption) {
					firstOption.focus();
				}
			}
		});

		if (searchInput) {
			searchInput.addEventListener('input', () => {
				filterPanelOptions(panel, searchInput, '.ecdf-country-option');
			});

			searchInput.addEventListener('keydown', (event) => {
				if (event.key === 'ArrowDown') {
					event.preventDefault();
					const firstOption = getVisibleOptions(panel, '.ecdf-country-option')[0];
					if (firstOption) {
						firstOption.focus();
					}
				}

				if (event.key === 'Escape') {
					event.preventDefault();
					closeCountryField(field);
					trigger.focus();
				}
			});
		}

		panel.addEventListener('keydown', (event) => {
			const focusedOption = document.activeElement.closest('.ecdf-country-option');

			if (event.key === 'Escape') {
				event.preventDefault();
				closeCountryField(field);
				trigger.focus();
				return;
			}

			if (!focusedOption) {
				return;
			}

			if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
				event.preventDefault();

				const options = getVisibleOptions(panel, '.ecdf-country-option');
				const currentIndex = options.indexOf(focusedOption);
				const nextIndex = event.key === 'ArrowDown'
					? Math.min(currentIndex + 1, options.length - 1)
					: Math.max(currentIndex - 1, 0);

				if (options[nextIndex]) {
					options[nextIndex].focus();
				}
			}
		});

		const form = field.closest('form');
		if (form) {
			form.addEventListener('reset', () => {
				window.setTimeout(() => {
					syncCountrySelectedOption(field, select, selectedContainer);
					closeCountryField(field);
				}, 0);
			});
		}
	}

	function getCountrySelectionCode(form) {
		if (!form) {
			return '';
		}

		const countryField = form.querySelector(COUNTRY_FIELD_SELECTOR);
		const select = countryField ? countryField.querySelector('[data-ecdf-role="native"]') : null;
		const selectedOption = select && select.options[select.selectedIndex] ? select.options[select.selectedIndex] : null;

		return selectedOption && select.value ? (selectedOption.dataset.code || '') : '';
	}

	function selectCountryFieldByCode(form, countryCode) {
		if (!form || !countryCode) {
			return;
		}

		const countryField = form.querySelector(COUNTRY_FIELD_SELECTOR);
		if (!countryField) {
			return;
		}

		const select = countryField.querySelector('[data-ecdf-role="native"]');
		const optionButton = findOptionByCountryCode(countryField, '.ecdf-country-option', countryCode);

		if (!select || !optionButton) {
			return;
		}

		if (select.value === (optionButton.dataset.name || '')) {
			return;
		}

		select.value = optionButton.dataset.name || '';
		select.dispatchEvent(new Event('input', { bubbles: true }));
		select.dispatchEvent(new Event('change', { bubbles: true }));
	}

	function closeMobileField(field) {
		const trigger = field.querySelector('[data-ecdf-role="mobile-trigger"]');
		const panel = field.querySelector('[data-ecdf-role="mobile-panel"]');
		const searchInput = field.querySelector('[data-ecdf-role="mobile-search"]');

		field.classList.remove('is-open');

		if (trigger) {
			trigger.setAttribute('aria-expanded', 'false');
		}

		if (panel) {
			resetPanelFilter(panel, searchInput, '.ecdf-mobile-option');
		}
	}

	function closeAllMobileFields(exceptField = null) {
		document.querySelectorAll(MOBILE_FIELD_SELECTOR + '.is-open').forEach((field) => {
			if (field !== exceptField) {
				closeMobileField(field);
			}
		});
	}

	function updateMobileSubmission(submissionInput, numberInput, selectedOption) {
		if (!submissionInput || !numberInput) {
			return;
		}

		const number = numberInput.value.trim();
		const dial = selectedOption ? (selectedOption.dataset.dial || '') : '';

		submissionInput.value = number ? `${dial ? `${dial} ` : ''}${number}`.trim() : '';
		submissionInput.dispatchEvent(new Event('input', { bubbles: true }));
		submissionInput.dispatchEvent(new Event('change', { bubbles: true }));
	}

	function updateMobileSelectedDisplay(selectedContainer, selectedOption) {
		if (!selectedContainer || !selectedOption) {
			if (selectedContainer) {
				selectedContainer.innerHTML = '<span class="ecdf-mobile-code-placeholder">Code</span>';
			}
			return;
		}

		const flag = flagEmoji(selectedOption.dataset.code || '');
		const dial = selectedOption.dataset.dial || '';

		selectedContainer.innerHTML = `
			<span class="ecdf-country-flag" aria-hidden="true">${escapeHtml(flag)}</span>
			<span class="ecdf-mobile-selected-dial">${escapeHtml(dial)}</span>
		`;
	}

	function setMobileSelectedOption(field, optionButton, options = {}) {
		const shouldSyncCountry = options.syncCountry !== false;
		const shouldClose = options.close !== false;
		const submissionInput = field.querySelector('[data-ecdf-role="mobile-submission"]');
		const countryHiddenInput = field.querySelector('[data-ecdf-role="mobile-country-hidden"]');
		const numberInput = field.querySelector('[data-ecdf-role="mobile-number"]');
		const selectedContainer = field.querySelector('[data-ecdf-role="mobile-selected"]');
		const form = field.closest('form');

		if (!optionButton || !submissionInput || !countryHiddenInput || !numberInput || !selectedContainer) {
			return;
		}

		field.querySelectorAll('.ecdf-mobile-option').forEach((button) => {
			const isSelected = button === optionButton;
			button.classList.toggle('is-selected', isSelected);
			button.setAttribute('aria-selected', isSelected ? 'true' : 'false');
		});

		countryHiddenInput.value = optionButton.dataset.code || '';
		updateMobileSelectedDisplay(selectedContainer, optionButton);
		updateMobileSubmission(submissionInput, numberInput, optionButton);

		if (shouldSyncCountry && form) {
			selectCountryFieldByCode(form, optionButton.dataset.code || '');
		}

		if (shouldClose) {
			closeMobileField(field);
		}
	}

	function syncMobileFromCountryCode(field, countryCode) {
		if (!field || !countryCode) {
			return;
		}

		const optionButton = findOptionByCountryCode(field, '.ecdf-mobile-option', countryCode);
		if (optionButton) {
			setMobileSelectedOption(field, optionButton, { syncCountry: false, close: false });
		}
	}

	function initMobileField(field) {
		if (!field || field.dataset.ecdfMobileInitialized === 'true') {
			return;
		}

		const submissionInput = field.querySelector('[data-ecdf-role="mobile-submission"]');
		const countryHiddenInput = field.querySelector('[data-ecdf-role="mobile-country-hidden"]');
		const numberInput = field.querySelector('[data-ecdf-role="mobile-number"]');
		const trigger = field.querySelector('[data-ecdf-role="mobile-trigger"]');
		const panel = field.querySelector('[data-ecdf-role="mobile-panel"]');
		const selectedContainer = field.querySelector('[data-ecdf-role="mobile-selected"]');
		const searchInput = field.querySelector('[data-ecdf-role="mobile-search"]');

		if (!submissionInput || !countryHiddenInput || !numberInput || !trigger || !panel || !selectedContainer) {
			return;
		}

		field.dataset.ecdfMobileInitialized = 'true';

		const fieldNameMatch = submissionInput.name ? submissionInput.name.match(/^form_fields\[(.+?)\]$/) : null;
		if (fieldNameMatch && fieldNameMatch[1]) {
			countryHiddenInput.name = `ecdf_mobile_country[${fieldNameMatch[1]}]`;
		}

		trigger.addEventListener('click', () => {
			const willOpen = !field.classList.contains('is-open');

			closeAllMobileFields(field);
			closeAllCountryFields();
			field.classList.toggle('is-open', willOpen);
			trigger.setAttribute('aria-expanded', willOpen ? 'true' : 'false');

			if (willOpen) {
				window.setTimeout(() => {
					if (searchInput) {
						searchInput.focus();
						return;
					}

					const currentOption = field.querySelector('.ecdf-mobile-option.is-selected');
					if (currentOption) {
						currentOption.scrollIntoView({ block: 'nearest' });
					}
				}, 0);
			}
		});

		field.querySelectorAll('.ecdf-mobile-option').forEach((optionButton) => {
			optionButton.addEventListener('click', () => {
				setMobileSelectedOption(field, optionButton);
				trigger.focus();
			});
		});

		numberInput.addEventListener('input', () => {
			const activeOption = field.querySelector('.ecdf-mobile-option.is-selected');
			updateMobileSubmission(submissionInput, numberInput, activeOption);
		});

		trigger.addEventListener('keydown', (event) => {
			if (event.key === 'ArrowDown' || event.key === 'Enter' || event.key === ' ') {
				event.preventDefault();

				if (!field.classList.contains('is-open')) {
					trigger.click();
				}

				if (searchInput) {
					searchInput.focus();
					return;
				}

				const firstOption = getVisibleOptions(panel, '.ecdf-mobile-option')[0];
				if (firstOption) {
					firstOption.focus();
				}
			}
		});

		if (searchInput) {
			searchInput.addEventListener('input', () => {
				filterPanelOptions(panel, searchInput, '.ecdf-mobile-option');
			});

			searchInput.addEventListener('keydown', (event) => {
				if (event.key === 'ArrowDown') {
					event.preventDefault();
					const firstOption = getVisibleOptions(panel, '.ecdf-mobile-option')[0];
					if (firstOption) {
						firstOption.focus();
					}
				}

				if (event.key === 'Escape') {
					event.preventDefault();
					closeMobileField(field);
					trigger.focus();
				}
			});
		}

		panel.addEventListener('keydown', (event) => {
			const focusedOption = document.activeElement.closest('.ecdf-mobile-option');

			if (event.key === 'Escape') {
				event.preventDefault();
				closeMobileField(field);
				trigger.focus();
				return;
			}

			if (!focusedOption) {
				return;
			}

			if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
				event.preventDefault();

				const options = getVisibleOptions(panel, '.ecdf-mobile-option');
				const currentIndex = options.indexOf(focusedOption);
				const nextIndex = event.key === 'ArrowDown'
					? Math.min(currentIndex + 1, options.length - 1)
					: Math.max(currentIndex - 1, 0);

				if (options[nextIndex]) {
					options[nextIndex].focus();
				}
			}
		});

		const form = field.closest('form');
		if (form) {
			const selectedCountryCode = getCountrySelectionCode(form);
			if (selectedCountryCode) {
				syncMobileFromCountryCode(field, selectedCountryCode);
			}

			form.addEventListener('ecdf:country-change', (event) => {
				if (event.detail && event.detail.code) {
					syncMobileFromCountryCode(field, event.detail.code);
				}
			});

			form.addEventListener('reset', () => {
				window.setTimeout(() => {
					countryHiddenInput.value = '';
					updateMobileSelectedDisplay(selectedContainer, null);
					updateMobileSubmission(submissionInput, numberInput, null);
					closeMobileField(field);
					const resetCountryCode = getCountrySelectionCode(form);
					if (resetCountryCode) {
						syncMobileFromCountryCode(field, resetCountryCode);
					}
				}, 0);
			});
		}
	}

	function initAllCountryFields(scope = document) {
		scope.querySelectorAll(COUNTRY_FIELD_SELECTOR).forEach(initCountryField);
	}

	function initAllMobileFields(scope = document) {
		scope.querySelectorAll(MOBILE_FIELD_SELECTOR).forEach(initMobileField);
	}

	document.addEventListener('DOMContentLoaded', () => {
		initAllCountryFields(document);
		initAllMobileFields(document);
	});

	document.addEventListener('click', (event) => {
		if (!event.target.closest(COUNTRY_FIELD_SELECTOR)) {
			closeAllCountryFields();
		}

		if (!event.target.closest(MOBILE_FIELD_SELECTOR)) {
			closeAllMobileFields();
		}
	});

	document.addEventListener('keydown', (event) => {
		if (event.key === 'Escape') {
			closeAllCountryFields();
			closeAllMobileFields();
		}
	});

	window.addEventListener('elementor/frontend/init', () => {
		if (!window.elementorFrontend || !window.elementorFrontend.hooks) {
			return;
		}

		window.elementorFrontend.hooks.addAction('frontend/element_ready/form.default', ($scope) => {
			const root = $scope && $scope[0] ? $scope[0] : document;
			initAllCountryFields(root);
			initAllMobileFields(root);
		});
	});
})();
