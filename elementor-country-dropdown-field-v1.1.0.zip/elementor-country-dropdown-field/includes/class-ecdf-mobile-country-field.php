<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor Pro Forms field: Mobile Number + Country Code.
 */
class ECDF_Mobile_Country_Field extends \ElementorPro\Modules\Forms\Fields\Field_Base {

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct();
		add_action( 'elementor/preview/init', [ $this, 'editor_preview_footer' ] );
	}

	/**
	 * Unique Elementor field type slug.
	 *
	 * @return string
	 */
	public function get_type(): string {
		return 'mobile-country';
	}

	/**
	 * Field label shown inside the Elementor Form "Type" dropdown.
	 *
	 * @return string
	 */
	public function get_name(): string {
		return esc_html__( 'Mobile Number + Country Code', 'elementor-country-dropdown-field' );
	}

	/**
	 * Frontend JS dependency.
	 *
	 * @return array
	 */
	public function get_script_depends(): array {
		return [ 'ecdf-country-field' ];
	}

	/**
	 * Frontend CSS dependency.
	 *
	 * @return array
	 */
	public function get_style_depends(): array {
		return [ 'ecdf-country-field' ];
	}

	/**
	 * Render the field HTML.
	 *
	 * @param array $item Field settings.
	 * @param int   $item_index Field index.
	 * @param mixed $form Elementor form widget instance.
	 * @return void
	 */
	public function render( $item, $item_index, $form ): void {
		$countries          = self::get_country_meta();
		$number_placeholder = ! empty( $item['placeholder'] )
			? (string) $item['placeholder']
			: esc_html__( 'Mobile Number', 'elementor-country-dropdown-field' );
		$is_required        = ! empty( $item['required'] );
		$required_attr      = $is_required ? ' required' : '';
		$aria_required      = $is_required ? ' aria-required="true"' : '';

		$form->add_render_attribute(
			'input' . $item_index,
			[
				'type'           => 'hidden',
				'class'          => [ 'ecdf-mobile-submission' ],
				'data-ecdf-role' => 'mobile-submission',
			]
		);

		echo '<div class="ecdf-mobile-field" data-ecdf-mobile-field>';
		echo '<input ' . $form->get_render_attribute_string( 'input' . $item_index ) . '>';
		echo '<input type="hidden" data-ecdf-role="mobile-country-hidden" value="">';

		echo '<div class="ecdf-mobile-control">';
		echo '<div class="ecdf-mobile-code-picker">';
		echo '<button type="button" class="ecdf-mobile-code-trigger elementor-field elementor-field-textual" data-ecdf-role="mobile-trigger" aria-haspopup="listbox" aria-expanded="false">';
		echo '<span class="ecdf-mobile-code-selected" data-ecdf-role="mobile-selected">';
		echo '<span class="ecdf-mobile-code-placeholder">' . esc_html__( 'Code', 'elementor-country-dropdown-field' ) . '</span>';
		echo '</span>';
		echo '<span class="ecdf-country-chevron" aria-hidden="true"></span>';
		echo '</button>';

		echo '<div class="ecdf-mobile-panel" data-ecdf-role="mobile-panel" role="listbox" tabindex="-1">';
		echo '<div class="ecdf-dropdown-search-wrap">';
		echo '<input type="search" class="ecdf-dropdown-search" data-ecdf-role="mobile-search" placeholder="' . esc_attr__( 'Search country or code...', 'elementor-country-dropdown-field' ) . '" autocomplete="off" aria-label="' . esc_attr__( 'Search country or code', 'elementor-country-dropdown-field' ) . '">';
		echo '</div>';

		foreach ( $countries as $code => $country ) {
			$search_value = strtolower( remove_accents( $country['name'] . ' ' . $code . ' ' . $country['dial'] ) );
			printf(
				'<button type="button" class="ecdf-mobile-option" role="option" data-code="%1$s" data-name="%2$s" data-dial="%3$s" data-search="%4$s" aria-selected="false"><span class="ecdf-country-flag" aria-hidden="true">%5$s</span><span class="ecdf-mobile-option-country">%6$s</span><span class="ecdf-mobile-option-dial">%7$s</span></button>',
				esc_attr( $code ),
				esc_attr( $country['name'] ),
				esc_attr( $country['dial'] ),
				esc_attr( $search_value ),
				esc_html( self::get_flag_emoji( $code ) ),
				esc_html( $country['name'] ),
				esc_html( $country['dial'] )
			);
		}

		echo '</div>';
		echo '</div>';

		printf(
			'<input type="tel" class="ecdf-mobile-number elementor-field elementor-field-textual" data-ecdf-role="mobile-number" placeholder="%1$s" inputmode="tel" autocomplete="tel-national"%2$s%3$s>',
			esc_attr( $number_placeholder ),
			$required_attr,
			$aria_required
		);

		echo '</div>';
		echo '</div>';
	}

	/**
	 * Validate submitted value and ensure the phone country matches the Country Dropdown field.
	 *
	 * @param array                                                        $field Submitted field data.
	 * @param \ElementorPro\Modules\Forms\Classes\Form_Record            $record Form record.
	 * @param \ElementorPro\Modules\Forms\Classes\Ajax_Handler           $ajax_handler AJAX handler.
	 * @return void
	 */
	public function validation( $field, $record, $ajax_handler ): void {
		$value = isset( $field['value'] ) ? trim( (string) $field['value'] ) : '';

		if ( ! empty( $field['required'] ) && '' === $value ) {
			$ajax_handler->add_error(
				$field['id'],
				esc_html__( 'Please enter your mobile number.', 'elementor-country-dropdown-field' )
			);
			return;
		}

		if ( '' === $value ) {
			return;
		}

		$digits_only = preg_replace( '/\D+/', '', $value );
		if ( strlen( (string) $digits_only ) < 5 ) {
			$ajax_handler->add_error(
				$field['id'],
				esc_html__( 'Please enter a valid mobile number.', 'elementor-country-dropdown-field' )
			);
			return;
		}

		$mobile_country_iso = self::get_posted_mobile_country_iso( (string) $field['id'] );
		$country_meta       = self::get_country_meta();

		if ( '' === $mobile_country_iso || ! isset( $country_meta[ $mobile_country_iso ] ) ) {
			$ajax_handler->add_error(
				$field['id'],
				esc_html__( 'Please choose a country code for your mobile number.', 'elementor-country-dropdown-field' )
			);
			return;
		}

		$selected_country_iso = self::find_selected_country_iso_from_record( $record );

		if ( '' !== $selected_country_iso && $selected_country_iso !== $mobile_country_iso ) {
			$ajax_handler->add_error(
				$field['id'],
				esc_html__( 'The mobile country code must match the selected Country field.', 'elementor-country-dropdown-field' )
			);
		}
	}

	/**
	 * Register an editor preview template so the field appears immediately in Elementor editor.
	 *
	 * @return void
	 */
	public function editor_preview_footer(): void {
		add_action( 'wp_footer', [ $this, 'content_template_script' ] );
	}

	/**
	 * Elementor editor preview template.
	 *
	 * @return void
	 */
	public function content_template_script(): void {
		?>
		<script>
			jQuery( document ).ready( () => {
				elementor.hooks.addFilter(
					'elementor_pro/forms/content_template/field/<?php echo esc_js( $this->get_type() ); ?>',
					function( inputField, item ) {
						const placeholder = item.placeholder || '<?php echo esc_js( esc_html__( 'Mobile Number', 'elementor-country-dropdown-field' ) ); ?>';

						return `
							<div class="ecdf-mobile-field ecdf-mobile-field--preview">
								<div class="ecdf-mobile-control">
									<button type="button" class="ecdf-mobile-code-trigger elementor-field elementor-field-textual" disabled>
										<span class="ecdf-mobile-code-selected">
											<span class="ecdf-mobile-code-placeholder"><?php echo esc_js( esc_html__( 'Code', 'elementor-country-dropdown-field' ) ); ?></span>
										</span>
										<span class="ecdf-country-chevron" aria-hidden="true"></span>
									</button>
									<input type="tel" class="ecdf-mobile-number elementor-field elementor-field-textual" placeholder="${ _.escape( placeholder ) }" disabled>
								</div>
							</div>
						`;
					},
					10,
					3
				);
			});
		</script>
		<?php
	}

	/**
	 * Get the posted ISO country code for a mobile custom field.
	 *
	 * @param string $field_id Field ID.
	 * @return string
	 */
	private static function get_posted_mobile_country_iso( string $field_id ): string {
		if ( ! isset( $_POST['ecdf_mobile_country'] ) || ! is_array( $_POST['ecdf_mobile_country'] ) ) {
			return '';
		}

		$posted_countries = wp_unslash( $_POST['ecdf_mobile_country'] );
		if ( ! isset( $posted_countries[ $field_id ] ) ) {
			return '';
		}

		return strtoupper( sanitize_text_field( (string) $posted_countries[ $field_id ] ) );
	}

	/**
	 * Find the selected ISO code from the Country Dropdown field within the same Elementor submission.
	 *
	 * @param \ElementorPro\Modules\Forms\Classes\Form_Record $record Form record.
	 * @return string
	 */
	private static function find_selected_country_iso_from_record( $record ): string {
		$fields = $record->get( 'fields' );

		if ( ! is_array( $fields ) ) {
			return '';
		}

		$fallback_iso = '';

		foreach ( $fields as $candidate ) {
			if ( ! is_array( $candidate ) ) {
				continue;
			}

			$value = isset( $candidate['value'] ) ? trim( (string) $candidate['value'] ) : '';
			if ( '' === $value ) {
				continue;
			}

			$iso = self::get_iso_by_country_name( $value );
			if ( '' === $iso ) {
				continue;
			}

			if ( isset( $candidate['type'] ) && 'country-dropdown' === (string) $candidate['type'] ) {
				return $iso;
			}

			if ( '' === $fallback_iso ) {
				$fallback_iso = $iso;
			}
		}

		return $fallback_iso;
	}

	/**
	 * Convert a country name to ISO alpha-2.
	 *
	 * @param string $country_name Country name.
	 * @return string
	 */
	private static function get_iso_by_country_name( string $country_name ): string {
		foreach ( self::get_country_meta() as $iso => $country ) {
			if ( $country_name === $country['name'] ) {
				return $iso;
			}
		}

		return '';
	}

	/**
	 * Return country metadata for the phone-country dropdown.
	 *
	 * @return array<string,array{name:string,dial:string}>
	 */
	private static function get_country_meta(): array {
		return [
			'AF' => [ 'name' => 'Afghanistan', 'dial' => '+93' ],
			'AL' => [ 'name' => 'Albania', 'dial' => '+355' ],
			'DZ' => [ 'name' => 'Algeria', 'dial' => '+213' ],
			'AS' => [ 'name' => 'American Samoa', 'dial' => '+1 684' ],
			'AD' => [ 'name' => 'Andorra', 'dial' => '+376' ],
			'AO' => [ 'name' => 'Angola', 'dial' => '+244' ],
			'AI' => [ 'name' => 'Anguilla', 'dial' => '+1 264' ],
			'AQ' => [ 'name' => 'Antarctica', 'dial' => '+672' ],
			'AG' => [ 'name' => 'Antigua and Barbuda', 'dial' => '+1 268' ],
			'AR' => [ 'name' => 'Argentina', 'dial' => '+54' ],
			'AM' => [ 'name' => 'Armenia', 'dial' => '+374' ],
			'AW' => [ 'name' => 'Aruba', 'dial' => '+297' ],
			'AU' => [ 'name' => 'Australia', 'dial' => '+61' ],
			'AT' => [ 'name' => 'Austria', 'dial' => '+43' ],
			'AZ' => [ 'name' => 'Azerbaijan', 'dial' => '+994' ],
			'BS' => [ 'name' => 'Bahamas', 'dial' => '+1 242' ],
			'BH' => [ 'name' => 'Bahrain', 'dial' => '+973' ],
			'BD' => [ 'name' => 'Bangladesh', 'dial' => '+880' ],
			'BB' => [ 'name' => 'Barbados', 'dial' => '+1 246' ],
			'BY' => [ 'name' => 'Belarus', 'dial' => '+375' ],
			'BE' => [ 'name' => 'Belgium', 'dial' => '+32' ],
			'BZ' => [ 'name' => 'Belize', 'dial' => '+501' ],
			'BJ' => [ 'name' => 'Benin', 'dial' => '+229' ],
			'BM' => [ 'name' => 'Bermuda', 'dial' => '+1 441' ],
			'BT' => [ 'name' => 'Bhutan', 'dial' => '+975' ],
			'BO' => [ 'name' => 'Bolivia', 'dial' => '+591' ],
			'BQ' => [ 'name' => 'Bonaire, Sint Eustatius and Saba', 'dial' => '+599' ],
			'BA' => [ 'name' => 'Bosnia and Herzegovina', 'dial' => '+387' ],
			'BW' => [ 'name' => 'Botswana', 'dial' => '+267' ],
			'BV' => [ 'name' => 'Bouvet Island', 'dial' => '+47' ],
			'BR' => [ 'name' => 'Brazil', 'dial' => '+55' ],
			'IO' => [ 'name' => 'British Indian Ocean Territory', 'dial' => '+246' ],
			'VG' => [ 'name' => 'British Virgin Islands', 'dial' => '+1 284' ],
			'BN' => [ 'name' => 'Brunei', 'dial' => '+673' ],
			'BG' => [ 'name' => 'Bulgaria', 'dial' => '+359' ],
			'BF' => [ 'name' => 'Burkina Faso', 'dial' => '+226' ],
			'BI' => [ 'name' => 'Burundi', 'dial' => '+257' ],
			'CV' => [ 'name' => 'Cabo Verde', 'dial' => '+238' ],
			'KH' => [ 'name' => 'Cambodia', 'dial' => '+855' ],
			'CM' => [ 'name' => 'Cameroon', 'dial' => '+237' ],
			'CA' => [ 'name' => 'Canada', 'dial' => '+1' ],
			'KY' => [ 'name' => 'Cayman Islands', 'dial' => '+1 345' ],
			'CF' => [ 'name' => 'Central African Republic', 'dial' => '+236' ],
			'TD' => [ 'name' => 'Chad', 'dial' => '+235' ],
			'CL' => [ 'name' => 'Chile', 'dial' => '+56' ],
			'CN' => [ 'name' => 'China', 'dial' => '+86' ],
			'CX' => [ 'name' => 'Christmas Island', 'dial' => '+61' ],
			'CC' => [ 'name' => 'Cocos (Keeling) Islands', 'dial' => '+61' ],
			'CO' => [ 'name' => 'Colombia', 'dial' => '+57' ],
			'KM' => [ 'name' => 'Comoros', 'dial' => '+269' ],
			'CK' => [ 'name' => 'Cook Islands', 'dial' => '+682' ],
			'CR' => [ 'name' => 'Costa Rica', 'dial' => '+506' ],
			'HR' => [ 'name' => 'Croatia', 'dial' => '+385' ],
			'CU' => [ 'name' => 'Cuba', 'dial' => '+53' ],
			'CW' => [ 'name' => 'Curaçao', 'dial' => '+599' ],
			'CY' => [ 'name' => 'Cyprus', 'dial' => '+357' ],
			'CZ' => [ 'name' => 'Czechia', 'dial' => '+420' ],
			'CI' => [ 'name' => 'Côte d\'Ivoire', 'dial' => '+225' ],
			'CD' => [ 'name' => 'Democratic Republic of the Congo', 'dial' => '+243' ],
			'DK' => [ 'name' => 'Denmark', 'dial' => '+45' ],
			'DJ' => [ 'name' => 'Djibouti', 'dial' => '+253' ],
			'DM' => [ 'name' => 'Dominica', 'dial' => '+1 767' ],
			'DO' => [ 'name' => 'Dominican Republic', 'dial' => '+1 809' ],
			'EC' => [ 'name' => 'Ecuador', 'dial' => '+593' ],
			'EG' => [ 'name' => 'Egypt', 'dial' => '+20' ],
			'SV' => [ 'name' => 'El Salvador', 'dial' => '+503' ],
			'GQ' => [ 'name' => 'Equatorial Guinea', 'dial' => '+240' ],
			'ER' => [ 'name' => 'Eritrea', 'dial' => '+291' ],
			'EE' => [ 'name' => 'Estonia', 'dial' => '+372' ],
			'SZ' => [ 'name' => 'Eswatini', 'dial' => '+268' ],
			'ET' => [ 'name' => 'Ethiopia', 'dial' => '+251' ],
			'FK' => [ 'name' => 'Falkland Islands', 'dial' => '+500' ],
			'FO' => [ 'name' => 'Faroe Islands', 'dial' => '+298' ],
			'FJ' => [ 'name' => 'Fiji', 'dial' => '+679' ],
			'FI' => [ 'name' => 'Finland', 'dial' => '+358' ],
			'FR' => [ 'name' => 'France', 'dial' => '+33' ],
			'GF' => [ 'name' => 'French Guiana', 'dial' => '+594' ],
			'PF' => [ 'name' => 'French Polynesia', 'dial' => '+689' ],
			'TF' => [ 'name' => 'French Southern Territories', 'dial' => '+262' ],
			'GA' => [ 'name' => 'Gabon', 'dial' => '+241' ],
			'GM' => [ 'name' => 'Gambia', 'dial' => '+220' ],
			'GE' => [ 'name' => 'Georgia', 'dial' => '+995' ],
			'DE' => [ 'name' => 'Germany', 'dial' => '+49' ],
			'GH' => [ 'name' => 'Ghana', 'dial' => '+233' ],
			'GI' => [ 'name' => 'Gibraltar', 'dial' => '+350' ],
			'GR' => [ 'name' => 'Greece', 'dial' => '+30' ],
			'GL' => [ 'name' => 'Greenland', 'dial' => '+299' ],
			'GD' => [ 'name' => 'Grenada', 'dial' => '+1 473' ],
			'GP' => [ 'name' => 'Guadeloupe', 'dial' => '+590' ],
			'GU' => [ 'name' => 'Guam', 'dial' => '+1 671' ],
			'GT' => [ 'name' => 'Guatemala', 'dial' => '+502' ],
			'GG' => [ 'name' => 'Guernsey', 'dial' => '+44 1481' ],
			'GN' => [ 'name' => 'Guinea', 'dial' => '+224' ],
			'GW' => [ 'name' => 'Guinea-Bissau', 'dial' => '+245' ],
			'GY' => [ 'name' => 'Guyana', 'dial' => '+592' ],
			'HT' => [ 'name' => 'Haiti', 'dial' => '+509' ],
			'HM' => [ 'name' => 'Heard Island and McDonald Islands', 'dial' => '+672' ],
			'VA' => [ 'name' => 'Holy See (Vatican City State)', 'dial' => '+379' ],
			'HN' => [ 'name' => 'Honduras', 'dial' => '+504' ],
			'HK' => [ 'name' => 'Hong Kong', 'dial' => '+852' ],
			'HU' => [ 'name' => 'Hungary', 'dial' => '+36' ],
			'IS' => [ 'name' => 'Iceland', 'dial' => '+354' ],
			'IN' => [ 'name' => 'India', 'dial' => '+91' ],
			'ID' => [ 'name' => 'Indonesia', 'dial' => '+62' ],
			'IR' => [ 'name' => 'Iran', 'dial' => '+98' ],
			'IQ' => [ 'name' => 'Iraq', 'dial' => '+964' ],
			'IE' => [ 'name' => 'Ireland', 'dial' => '+353' ],
			'IM' => [ 'name' => 'Isle of Man', 'dial' => '+44 1624' ],
			'IL' => [ 'name' => 'Israel', 'dial' => '+972' ],
			'IT' => [ 'name' => 'Italy', 'dial' => '+39' ],
			'JM' => [ 'name' => 'Jamaica', 'dial' => '+1 876' ],
			'JP' => [ 'name' => 'Japan', 'dial' => '+81' ],
			'JE' => [ 'name' => 'Jersey', 'dial' => '+44 1534' ],
			'JO' => [ 'name' => 'Jordan', 'dial' => '+962' ],
			'KZ' => [ 'name' => 'Kazakhstan', 'dial' => '+7' ],
			'KE' => [ 'name' => 'Kenya', 'dial' => '+254' ],
			'KI' => [ 'name' => 'Kiribati', 'dial' => '+686' ],
			'KW' => [ 'name' => 'Kuwait', 'dial' => '+965' ],
			'KG' => [ 'name' => 'Kyrgyzstan', 'dial' => '+996' ],
			'LA' => [ 'name' => 'Laos', 'dial' => '+856' ],
			'LV' => [ 'name' => 'Latvia', 'dial' => '+371' ],
			'LB' => [ 'name' => 'Lebanon', 'dial' => '+961' ],
			'LS' => [ 'name' => 'Lesotho', 'dial' => '+266' ],
			'LR' => [ 'name' => 'Liberia', 'dial' => '+231' ],
			'LY' => [ 'name' => 'Libya', 'dial' => '+218' ],
			'LI' => [ 'name' => 'Liechtenstein', 'dial' => '+423' ],
			'LT' => [ 'name' => 'Lithuania', 'dial' => '+370' ],
			'LU' => [ 'name' => 'Luxembourg', 'dial' => '+352' ],
			'MO' => [ 'name' => 'Macao', 'dial' => '+853' ],
			'MG' => [ 'name' => 'Madagascar', 'dial' => '+261' ],
			'MW' => [ 'name' => 'Malawi', 'dial' => '+265' ],
			'MY' => [ 'name' => 'Malaysia', 'dial' => '+60' ],
			'MV' => [ 'name' => 'Maldives', 'dial' => '+960' ],
			'ML' => [ 'name' => 'Mali', 'dial' => '+223' ],
			'MT' => [ 'name' => 'Malta', 'dial' => '+356' ],
			'MH' => [ 'name' => 'Marshall Islands', 'dial' => '+692' ],
			'MQ' => [ 'name' => 'Martinique', 'dial' => '+596' ],
			'MR' => [ 'name' => 'Mauritania', 'dial' => '+222' ],
			'MU' => [ 'name' => 'Mauritius', 'dial' => '+230' ],
			'YT' => [ 'name' => 'Mayotte', 'dial' => '+262' ],
			'MX' => [ 'name' => 'Mexico', 'dial' => '+52' ],
			'FM' => [ 'name' => 'Micronesia', 'dial' => '+691' ],
			'MD' => [ 'name' => 'Moldova', 'dial' => '+373' ],
			'MC' => [ 'name' => 'Monaco', 'dial' => '+377' ],
			'MN' => [ 'name' => 'Mongolia', 'dial' => '+976' ],
			'ME' => [ 'name' => 'Montenegro', 'dial' => '+382' ],
			'MS' => [ 'name' => 'Montserrat', 'dial' => '+1 664' ],
			'MA' => [ 'name' => 'Morocco', 'dial' => '+212' ],
			'MZ' => [ 'name' => 'Mozambique', 'dial' => '+258' ],
			'MM' => [ 'name' => 'Myanmar', 'dial' => '+95' ],
			'NA' => [ 'name' => 'Namibia', 'dial' => '+264' ],
			'NR' => [ 'name' => 'Nauru', 'dial' => '+674' ],
			'NP' => [ 'name' => 'Nepal', 'dial' => '+977' ],
			'NL' => [ 'name' => 'Netherlands', 'dial' => '+31' ],
			'NC' => [ 'name' => 'New Caledonia', 'dial' => '+687' ],
			'NZ' => [ 'name' => 'New Zealand', 'dial' => '+64' ],
			'NI' => [ 'name' => 'Nicaragua', 'dial' => '+505' ],
			'NE' => [ 'name' => 'Niger', 'dial' => '+227' ],
			'NG' => [ 'name' => 'Nigeria', 'dial' => '+234' ],
			'NU' => [ 'name' => 'Niue', 'dial' => '+683' ],
			'NF' => [ 'name' => 'Norfolk Island', 'dial' => '+672' ],
			'KP' => [ 'name' => 'North Korea', 'dial' => '+850' ],
			'MK' => [ 'name' => 'North Macedonia', 'dial' => '+389' ],
			'MP' => [ 'name' => 'Northern Mariana Islands', 'dial' => '+1 670' ],
			'NO' => [ 'name' => 'Norway', 'dial' => '+47' ],
			'OM' => [ 'name' => 'Oman', 'dial' => '+968' ],
			'PK' => [ 'name' => 'Pakistan', 'dial' => '+92' ],
			'PW' => [ 'name' => 'Palau', 'dial' => '+680' ],
			'PS' => [ 'name' => 'Palestine', 'dial' => '+970' ],
			'PA' => [ 'name' => 'Panama', 'dial' => '+507' ],
			'PG' => [ 'name' => 'Papua New Guinea', 'dial' => '+675' ],
			'PY' => [ 'name' => 'Paraguay', 'dial' => '+595' ],
			'PE' => [ 'name' => 'Peru', 'dial' => '+51' ],
			'PH' => [ 'name' => 'Philippines', 'dial' => '+63' ],
			'PN' => [ 'name' => 'Pitcairn', 'dial' => '+64' ],
			'PL' => [ 'name' => 'Poland', 'dial' => '+48' ],
			'PT' => [ 'name' => 'Portugal', 'dial' => '+351' ],
			'PR' => [ 'name' => 'Puerto Rico', 'dial' => '+1 787' ],
			'QA' => [ 'name' => 'Qatar', 'dial' => '+974' ],
			'CG' => [ 'name' => 'Republic of the Congo', 'dial' => '+242' ],
			'RO' => [ 'name' => 'Romania', 'dial' => '+40' ],
			'RU' => [ 'name' => 'Russia', 'dial' => '+7' ],
			'RW' => [ 'name' => 'Rwanda', 'dial' => '+250' ],
			'RE' => [ 'name' => 'Réunion', 'dial' => '+262' ],
			'BL' => [ 'name' => 'Saint Barthélemy', 'dial' => '+590' ],
			'SH' => [ 'name' => 'Saint Helena, Ascension and Tristan da Cunha', 'dial' => '+290' ],
			'KN' => [ 'name' => 'Saint Kitts and Nevis', 'dial' => '+1 869' ],
			'LC' => [ 'name' => 'Saint Lucia', 'dial' => '+1 758' ],
			'MF' => [ 'name' => 'Saint Martin (French part)', 'dial' => '+590' ],
			'PM' => [ 'name' => 'Saint Pierre and Miquelon', 'dial' => '+508' ],
			'VC' => [ 'name' => 'Saint Vincent and the Grenadines', 'dial' => '+1 784' ],
			'WS' => [ 'name' => 'Samoa', 'dial' => '+685' ],
			'SM' => [ 'name' => 'San Marino', 'dial' => '+378' ],
			'ST' => [ 'name' => 'Sao Tome and Principe', 'dial' => '+239' ],
			'SA' => [ 'name' => 'Saudi Arabia', 'dial' => '+966' ],
			'SN' => [ 'name' => 'Senegal', 'dial' => '+221' ],
			'RS' => [ 'name' => 'Serbia', 'dial' => '+381' ],
			'SC' => [ 'name' => 'Seychelles', 'dial' => '+248' ],
			'SL' => [ 'name' => 'Sierra Leone', 'dial' => '+232' ],
			'SG' => [ 'name' => 'Singapore', 'dial' => '+65' ],
			'SX' => [ 'name' => 'Sint Maarten (Dutch part)', 'dial' => '+1 721' ],
			'SK' => [ 'name' => 'Slovakia', 'dial' => '+421' ],
			'SI' => [ 'name' => 'Slovenia', 'dial' => '+386' ],
			'SB' => [ 'name' => 'Solomon Islands', 'dial' => '+677' ],
			'SO' => [ 'name' => 'Somalia', 'dial' => '+252' ],
			'ZA' => [ 'name' => 'South Africa', 'dial' => '+27' ],
			'GS' => [ 'name' => 'South Georgia and the South Sandwich Islands', 'dial' => '+500' ],
			'KR' => [ 'name' => 'South Korea', 'dial' => '+82' ],
			'SS' => [ 'name' => 'South Sudan', 'dial' => '+211' ],
			'ES' => [ 'name' => 'Spain', 'dial' => '+34' ],
			'LK' => [ 'name' => 'Sri Lanka', 'dial' => '+94' ],
			'SD' => [ 'name' => 'Sudan', 'dial' => '+249' ],
			'SR' => [ 'name' => 'Suriname', 'dial' => '+597' ],
			'SJ' => [ 'name' => 'Svalbard and Jan Mayen', 'dial' => '+47' ],
			'SE' => [ 'name' => 'Sweden', 'dial' => '+46' ],
			'CH' => [ 'name' => 'Switzerland', 'dial' => '+41' ],
			'SY' => [ 'name' => 'Syria', 'dial' => '+963' ],
			'TW' => [ 'name' => 'Taiwan', 'dial' => '+886' ],
			'TJ' => [ 'name' => 'Tajikistan', 'dial' => '+992' ],
			'TZ' => [ 'name' => 'Tanzania', 'dial' => '+255' ],
			'TH' => [ 'name' => 'Thailand', 'dial' => '+66' ],
			'TL' => [ 'name' => 'Timor-Leste', 'dial' => '+670' ],
			'TG' => [ 'name' => 'Togo', 'dial' => '+228' ],
			'TK' => [ 'name' => 'Tokelau', 'dial' => '+690' ],
			'TO' => [ 'name' => 'Tonga', 'dial' => '+676' ],
			'TT' => [ 'name' => 'Trinidad and Tobago', 'dial' => '+1 868' ],
			'TN' => [ 'name' => 'Tunisia', 'dial' => '+216' ],
			'TM' => [ 'name' => 'Turkmenistan', 'dial' => '+993' ],
			'TC' => [ 'name' => 'Turks and Caicos Islands', 'dial' => '+1 649' ],
			'TV' => [ 'name' => 'Tuvalu', 'dial' => '+688' ],
			'TR' => [ 'name' => 'Türkiye', 'dial' => '+90' ],
			'VI' => [ 'name' => 'U.S. Virgin Islands', 'dial' => '+1 340' ],
			'UG' => [ 'name' => 'Uganda', 'dial' => '+256' ],
			'UA' => [ 'name' => 'Ukraine', 'dial' => '+380' ],
			'AE' => [ 'name' => 'United Arab Emirates', 'dial' => '+971' ],
			'GB' => [ 'name' => 'United Kingdom', 'dial' => '+44' ],
			'US' => [ 'name' => 'United States', 'dial' => '+1' ],
			'UM' => [ 'name' => 'United States Minor Outlying Islands', 'dial' => '+1' ],
			'UY' => [ 'name' => 'Uruguay', 'dial' => '+598' ],
			'UZ' => [ 'name' => 'Uzbekistan', 'dial' => '+998' ],
			'VU' => [ 'name' => 'Vanuatu', 'dial' => '+678' ],
			'VE' => [ 'name' => 'Venezuela', 'dial' => '+58' ],
			'VN' => [ 'name' => 'Vietnam', 'dial' => '+84' ],
			'WF' => [ 'name' => 'Wallis and Futuna', 'dial' => '+681' ],
			'EH' => [ 'name' => 'Western Sahara', 'dial' => '+212' ],
			'YE' => [ 'name' => 'Yemen', 'dial' => '+967' ],
			'ZM' => [ 'name' => 'Zambia', 'dial' => '+260' ],
			'ZW' => [ 'name' => 'Zimbabwe', 'dial' => '+263' ],
			'AX' => [ 'name' => 'Åland Islands', 'dial' => '+358 18' ],
		];
	}

	/**
	 * Convert ISO-2 country code into a flag emoji.
	 *
	 * @param string $country_code ISO alpha-2 country code.
	 * @return string
	 */
	private static function get_flag_emoji( string $country_code ): string {
		$country_code = strtoupper( $country_code );
		$flag         = '';

		foreach ( str_split( $country_code ) as $letter ) {
			$flag .= html_entity_decode( '&#x' . dechex( 127397 + ord( $letter ) ) . ';', ENT_NOQUOTES, 'UTF-8' );
		}

		return $flag;
	}
}
