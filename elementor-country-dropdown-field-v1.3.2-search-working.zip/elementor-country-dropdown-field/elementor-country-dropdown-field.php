<?php
/**
 * Plugin Name: Elementor Country Dropdown + Mobile Sync Fields
 * Description: Adds two Elementor Pro Form fields: a searchable Country Dropdown and a searchable Mobile Number + Country Code field that stay in sync while inheriting Elementor form styling.
 * Version: 1.3.2
 * Author: Morosoft Custom
 * Text Domain: elementor-country-dropdown-field
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ECMSF_VERSION', '1.3.2' );
define( 'ECMSF_PLUGIN_FILE', __FILE__ );
define( 'ECMSF_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'ECMSF_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Register front-end assets. Elementor loads them when either custom field is present.
 */
function ecmsf_register_assets() {
	wp_register_style(
		'ecmsf-fields',
		ECMSF_PLUGIN_URL . 'assets/css/fields.css',
		[],
		ECMSF_VERSION
	);

	wp_register_script(
		'ecmsf-fields',
		ECMSF_PLUGIN_URL . 'assets/js/fields.js',
		[],
		ECMSF_VERSION,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'ecmsf_register_assets' );

/**
 * Register custom Elementor Pro form fields.
 *
 * @param mixed $form_fields_registrar Elementor field registrar.
 */
function ecmsf_register_form_fields( $form_fields_registrar ) {
	if ( ! class_exists( '\ElementorPro\Modules\Forms\Fields\Field_Base' ) ) {
		return;
	}

	require_once ECMSF_PLUGIN_PATH . 'includes/class-ecmsf-country-field.php';
	require_once ECMSF_PLUGIN_PATH . 'includes/class-ecmsf-mobile-field.php';

	$form_fields_registrar->register( new \ECMSF_Country_Field() );
	$form_fields_registrar->register( new \ECMSF_Mobile_Field() );
}
add_action( 'elementor_pro/forms/fields/register', 'ecmsf_register_form_fields' );

/**
 * Admin notice when Elementor Pro Forms is not available.
 */
function ecmsf_missing_elementor_pro_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	if ( class_exists( '\ElementorPro\Modules\Forms\Fields\Field_Base' ) ) {
		return;
	}

	echo '<div class="notice notice-warning"><p>';
	echo esc_html__( 'Elementor Country Dropdown + Mobile Sync Fields requires Elementor Pro Forms to be active.', 'elementor-country-dropdown-field' );
	echo '</p></div>';
}
add_action( 'admin_notices', 'ecmsf_missing_elementor_pro_notice' );
