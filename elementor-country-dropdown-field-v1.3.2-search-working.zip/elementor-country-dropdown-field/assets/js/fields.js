(function () {
	'use strict';

	var COUNTRIES = [{"iso":"AF","name":"Afghanistan","dial":"+93"},{"iso":"AL","name":"Albania","dial":"+355"},{"iso":"DZ","name":"Algeria","dial":"+213"},{"iso":"AS","name":"American Samoa","dial":"+1 684"},{"iso":"AD","name":"Andorra","dial":"+376"},{"iso":"AO","name":"Angola","dial":"+244"},{"iso":"AI","name":"Anguilla","dial":"+1 264"},{"iso":"AQ","name":"Antarctica","dial":"+672"},{"iso":"AG","name":"Antigua and Barbuda","dial":"+1 268"},{"iso":"AR","name":"Argentina","dial":"+54"},{"iso":"AM","name":"Armenia","dial":"+374"},{"iso":"AW","name":"Aruba","dial":"+297"},{"iso":"AU","name":"Australia","dial":"+61"},{"iso":"AT","name":"Austria","dial":"+43"},{"iso":"AZ","name":"Azerbaijan","dial":"+994"},{"iso":"BS","name":"Bahamas","dial":"+1 242"},{"iso":"BH","name":"Bahrain","dial":"+973"},{"iso":"BD","name":"Bangladesh","dial":"+880"},{"iso":"BB","name":"Barbados","dial":"+1 246"},{"iso":"BY","name":"Belarus","dial":"+375"},{"iso":"BE","name":"Belgium","dial":"+32"},{"iso":"BZ","name":"Belize","dial":"+501"},{"iso":"BJ","name":"Benin","dial":"+229"},{"iso":"BM","name":"Bermuda","dial":"+1 441"},{"iso":"BT","name":"Bhutan","dial":"+975"},{"iso":"BO","name":"Bolivia","dial":"+591"},{"iso":"BQ","name":"Bonaire, Sint Eustatius and Saba","dial":"+599"},{"iso":"BA","name":"Bosnia and Herzegovina","dial":"+387"},{"iso":"BW","name":"Botswana","dial":"+267"},{"iso":"BV","name":"Bouvet Island","dial":"+47"},{"iso":"BR","name":"Brazil","dial":"+55"},{"iso":"IO","name":"British Indian Ocean Territory","dial":"+246"},{"iso":"VG","name":"British Virgin Islands","dial":"+1 284"},{"iso":"BN","name":"Brunei","dial":"+673"},{"iso":"BG","name":"Bulgaria","dial":"+359"},{"iso":"BF","name":"Burkina Faso","dial":"+226"},{"iso":"BI","name":"Burundi","dial":"+257"},{"iso":"CV","name":"Cabo Verde","dial":"+238"},{"iso":"KH","name":"Cambodia","dial":"+855"},{"iso":"CM","name":"Cameroon","dial":"+237"},{"iso":"CA","name":"Canada","dial":"+1"},{"iso":"KY","name":"Cayman Islands","dial":"+1 345"},{"iso":"CF","name":"Central African Republic","dial":"+236"},{"iso":"TD","name":"Chad","dial":"+235"},{"iso":"CL","name":"Chile","dial":"+56"},{"iso":"CN","name":"China","dial":"+86"},{"iso":"CX","name":"Christmas Island","dial":"+61"},{"iso":"CC","name":"Cocos (Keeling) Islands","dial":"+61"},{"iso":"CO","name":"Colombia","dial":"+57"},{"iso":"KM","name":"Comoros","dial":"+269"},{"iso":"CK","name":"Cook Islands","dial":"+682"},{"iso":"CR","name":"Costa Rica","dial":"+506"},{"iso":"HR","name":"Croatia","dial":"+385"},{"iso":"CU","name":"Cuba","dial":"+53"},{"iso":"CW","name":"Curaçao","dial":"+599"},{"iso":"CY","name":"Cyprus","dial":"+357"},{"iso":"CZ","name":"Czechia","dial":"+420"},{"iso":"CD","name":"Democratic Republic of the Congo","dial":"+243"},{"iso":"DK","name":"Denmark","dial":"+45"},{"iso":"DJ","name":"Djibouti","dial":"+253"},{"iso":"DM","name":"Dominica","dial":"+1 767"},{"iso":"DO","name":"Dominican Republic","dial":"+1 809"},{"iso":"EC","name":"Ecuador","dial":"+593"},{"iso":"EG","name":"Egypt","dial":"+20"},{"iso":"SV","name":"El Salvador","dial":"+503"},{"iso":"GQ","name":"Equatorial Guinea","dial":"+240"},{"iso":"ER","name":"Eritrea","dial":"+291"},{"iso":"EE","name":"Estonia","dial":"+372"},{"iso":"SZ","name":"Eswatini","dial":"+268"},{"iso":"ET","name":"Ethiopia","dial":"+251"},{"iso":"FK","name":"Falkland Islands","dial":"+500"},{"iso":"FO","name":"Faroe Islands","dial":"+298"},{"iso":"FJ","name":"Fiji","dial":"+679"},{"iso":"FI","name":"Finland","dial":"+358"},{"iso":"FR","name":"France","dial":"+33"},{"iso":"GF","name":"French Guiana","dial":"+594"},{"iso":"PF","name":"French Polynesia","dial":"+689"},{"iso":"TF","name":"French Southern Territories","dial":"+262"},{"iso":"GA","name":"Gabon","dial":"+241"},{"iso":"GM","name":"Gambia","dial":"+220"},{"iso":"GE","name":"Georgia","dial":"+995"},{"iso":"DE","name":"Germany","dial":"+49"},{"iso":"GH","name":"Ghana","dial":"+233"},{"iso":"GI","name":"Gibraltar","dial":"+350"},{"iso":"GR","name":"Greece","dial":"+30"},{"iso":"GL","name":"Greenland","dial":"+299"},{"iso":"GD","name":"Grenada","dial":"+1 473"},{"iso":"GP","name":"Guadeloupe","dial":"+590"},{"iso":"GU","name":"Guam","dial":"+1 671"},{"iso":"GT","name":"Guatemala","dial":"+502"},{"iso":"GG","name":"Guernsey","dial":"+44 1481"},{"iso":"GN","name":"Guinea","dial":"+224"},{"iso":"GW","name":"Guinea-Bissau","dial":"+245"},{"iso":"GY","name":"Guyana","dial":"+592"},{"iso":"HT","name":"Haiti","dial":"+509"},{"iso":"HM","name":"Heard Island and McDonald Islands","dial":"+672"},{"iso":"VA","name":"Holy See (Vatican City State)","dial":"+379"},{"iso":"HN","name":"Honduras","dial":"+504"},{"iso":"HK","name":"Hong Kong","dial":"+852"},{"iso":"HU","name":"Hungary","dial":"+36"},{"iso":"IS","name":"Iceland","dial":"+354"},{"iso":"IN","name":"India","dial":"+91"},{"iso":"ID","name":"Indonesia","dial":"+62"},{"iso":"IR","name":"Iran","dial":"+98"},{"iso":"IQ","name":"Iraq","dial":"+964"},{"iso":"IE","name":"Ireland","dial":"+353"},{"iso":"IM","name":"Isle of Man","dial":"+44 1624"},{"iso":"IL","name":"Israel","dial":"+972"},{"iso":"IT","name":"Italy","dial":"+39"},{"iso":"JM","name":"Jamaica","dial":"+1 876"},{"iso":"JP","name":"Japan","dial":"+81"},{"iso":"JE","name":"Jersey","dial":"+44 1534"},{"iso":"JO","name":"Jordan","dial":"+962"},{"iso":"KZ","name":"Kazakhstan","dial":"+7"},{"iso":"KE","name":"Kenya","dial":"+254"},{"iso":"KI","name":"Kiribati","dial":"+686"},{"iso":"KW","name":"Kuwait","dial":"+965"},{"iso":"KG","name":"Kyrgyzstan","dial":"+996"},{"iso":"LA","name":"Laos","dial":"+856"},{"iso":"LV","name":"Latvia","dial":"+371"},{"iso":"LB","name":"Lebanon","dial":"+961"},{"iso":"LS","name":"Lesotho","dial":"+266"},{"iso":"LR","name":"Liberia","dial":"+231"},{"iso":"LY","name":"Libya","dial":"+218"},{"iso":"LI","name":"Liechtenstein","dial":"+423"},{"iso":"LT","name":"Lithuania","dial":"+370"},{"iso":"LU","name":"Luxembourg","dial":"+352"},{"iso":"MO","name":"Macao","dial":"+853"},{"iso":"MG","name":"Madagascar","dial":"+261"},{"iso":"MW","name":"Malawi","dial":"+265"},{"iso":"MY","name":"Malaysia","dial":"+60"},{"iso":"MV","name":"Maldives","dial":"+960"},{"iso":"ML","name":"Mali","dial":"+223"},{"iso":"MT","name":"Malta","dial":"+356"},{"iso":"MH","name":"Marshall Islands","dial":"+692"},{"iso":"MQ","name":"Martinique","dial":"+596"},{"iso":"MR","name":"Mauritania","dial":"+222"},{"iso":"MU","name":"Mauritius","dial":"+230"},{"iso":"YT","name":"Mayotte","dial":"+262"},{"iso":"MX","name":"Mexico","dial":"+52"},{"iso":"FM","name":"Micronesia","dial":"+691"},{"iso":"MD","name":"Moldova","dial":"+373"},{"iso":"MC","name":"Monaco","dial":"+377"},{"iso":"MN","name":"Mongolia","dial":"+976"},{"iso":"ME","name":"Montenegro","dial":"+382"},{"iso":"MS","name":"Montserrat","dial":"+1 664"},{"iso":"MA","name":"Morocco","dial":"+212"},{"iso":"MZ","name":"Mozambique","dial":"+258"},{"iso":"MM","name":"Myanmar","dial":"+95"},{"iso":"NA","name":"Namibia","dial":"+264"},{"iso":"NR","name":"Nauru","dial":"+674"},{"iso":"NP","name":"Nepal","dial":"+977"},{"iso":"NL","name":"Netherlands","dial":"+31"},{"iso":"NC","name":"New Caledonia","dial":"+687"},{"iso":"NZ","name":"New Zealand","dial":"+64"},{"iso":"NI","name":"Nicaragua","dial":"+505"},{"iso":"NE","name":"Niger","dial":"+227"},{"iso":"NG","name":"Nigeria","dial":"+234"},{"iso":"NU","name":"Niue","dial":"+683"},{"iso":"NF","name":"Norfolk Island","dial":"+672"},{"iso":"KP","name":"North Korea","dial":"+850"},{"iso":"MK","name":"North Macedonia","dial":"+389"},{"iso":"MP","name":"Northern Mariana Islands","dial":"+1 670"},{"iso":"NO","name":"Norway","dial":"+47"},{"iso":"OM","name":"Oman","dial":"+968"},{"iso":"PK","name":"Pakistan","dial":"+92"},{"iso":"PW","name":"Palau","dial":"+680"},{"iso":"PS","name":"Palestine","dial":"+970"},{"iso":"PA","name":"Panama","dial":"+507"},{"iso":"PG","name":"Papua New Guinea","dial":"+675"},{"iso":"PY","name":"Paraguay","dial":"+595"},{"iso":"PE","name":"Peru","dial":"+51"},{"iso":"PH","name":"Philippines","dial":"+63"},{"iso":"PN","name":"Pitcairn","dial":"+64"},{"iso":"PL","name":"Poland","dial":"+48"},{"iso":"PT","name":"Portugal","dial":"+351"},{"iso":"PR","name":"Puerto Rico","dial":"+1 787"},{"iso":"QA","name":"Qatar","dial":"+974"},{"iso":"CG","name":"Republic of the Congo","dial":"+242"},{"iso":"RO","name":"Romania","dial":"+40"},{"iso":"RU","name":"Russia","dial":"+7"},{"iso":"RW","name":"Rwanda","dial":"+250"},{"iso":"RE","name":"Réunion","dial":"+262"},{"iso":"BL","name":"Saint Barthélemy","dial":"+590"},{"iso":"SH","name":"Saint Helena, Ascension and Tristan da Cunha","dial":"+290"},{"iso":"KN","name":"Saint Kitts and Nevis","dial":"+1 869"},{"iso":"LC","name":"Saint Lucia","dial":"+1 758"},{"iso":"MF","name":"Saint Martin (French part)","dial":"+590"},{"iso":"PM","name":"Saint Pierre and Miquelon","dial":"+508"},{"iso":"VC","name":"Saint Vincent and the Grenadines","dial":"+1 784"},{"iso":"WS","name":"Samoa","dial":"+685"},{"iso":"SM","name":"San Marino","dial":"+378"},{"iso":"ST","name":"Sao Tome and Principe","dial":"+239"},{"iso":"SA","name":"Saudi Arabia","dial":"+966"},{"iso":"SN","name":"Senegal","dial":"+221"},{"iso":"RS","name":"Serbia","dial":"+381"},{"iso":"SC","name":"Seychelles","dial":"+248"},{"iso":"SL","name":"Sierra Leone","dial":"+232"},{"iso":"SG","name":"Singapore","dial":"+65"},{"iso":"SX","name":"Sint Maarten (Dutch part)","dial":"+1 721"},{"iso":"SK","name":"Slovakia","dial":"+421"},{"iso":"SI","name":"Slovenia","dial":"+386"},{"iso":"SB","name":"Solomon Islands","dial":"+677"},{"iso":"SO","name":"Somalia","dial":"+252"},{"iso":"ZA","name":"South Africa","dial":"+27"},{"iso":"GS","name":"South Georgia and the South Sandwich Islands","dial":"+500"},{"iso":"KR","name":"South Korea","dial":"+82"},{"iso":"SS","name":"South Sudan","dial":"+211"},{"iso":"ES","name":"Spain","dial":"+34"},{"iso":"LK","name":"Sri Lanka","dial":"+94"},{"iso":"SD","name":"Sudan","dial":"+249"},{"iso":"SR","name":"Suriname","dial":"+597"},{"iso":"SJ","name":"Svalbard and Jan Mayen","dial":"+47"},{"iso":"SE","name":"Sweden","dial":"+46"},{"iso":"CH","name":"Switzerland","dial":"+41"},{"iso":"SY","name":"Syria","dial":"+963"},{"iso":"TW","name":"Taiwan","dial":"+886"},{"iso":"TJ","name":"Tajikistan","dial":"+992"},{"iso":"TZ","name":"Tanzania","dial":"+255"},{"iso":"TH","name":"Thailand","dial":"+66"},{"iso":"TL","name":"Timor-Leste","dial":"+670"},{"iso":"TG","name":"Togo","dial":"+228"},{"iso":"TK","name":"Tokelau","dial":"+690"},{"iso":"TO","name":"Tonga","dial":"+676"},{"iso":"TT","name":"Trinidad and Tobago","dial":"+1 868"},{"iso":"TN","name":"Tunisia","dial":"+216"},{"iso":"TM","name":"Turkmenistan","dial":"+993"},{"iso":"TC","name":"Turks and Caicos Islands","dial":"+1 649"},{"iso":"TV","name":"Tuvalu","dial":"+688"},{"iso":"TR","name":"Türkiye","dial":"+90"},{"iso":"VI","name":"U.S. Virgin Islands","dial":"+1 340"},{"iso":"UG","name":"Uganda","dial":"+256"},{"iso":"UA","name":"Ukraine","dial":"+380"},{"iso":"AE","name":"United Arab Emirates","dial":"+971"},{"iso":"GB","name":"United Kingdom","dial":"+44"},{"iso":"US","name":"United States","dial":"+1"},{"iso":"UM","name":"United States Minor Outlying Islands","dial":"+1"},{"iso":"UY","name":"Uruguay","dial":"+598"},{"iso":"UZ","name":"Uzbekistan","dial":"+998"},{"iso":"VU","name":"Vanuatu","dial":"+678"},{"iso":"VE","name":"Venezuela","dial":"+58"},{"iso":"VN","name":"Vietnam","dial":"+84"},{"iso":"WF","name":"Wallis and Futuna","dial":"+681"},{"iso":"EH","name":"Western Sahara","dial":"+212"},{"iso":"YE","name":"Yemen","dial":"+967"},{"iso":"ZM","name":"Zambia","dial":"+260"},{"iso":"ZW","name":"Zimbabwe","dial":"+263"},{"iso":"AX","name":"Åland Islands","dial":"+358 18"}];
	var COUNTRY_SELECTOR = '[data-ecmsf-country-field]';
	var MOBILE_SELECTOR = '[data-ecmsf-mobile-field]';

	function escapeHtml(value) {
		return String(value || '')
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#039;');
	}

	function normalizeSearch(value) {
		var normalized = String(value || '');
		if (normalized.normalize) {
			normalized = normalized.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
		}
		return normalized.toLowerCase().trim();
	}

	function flagEmoji(iso) {
		if (!iso || !String.fromCodePoint) {
			return '';
		}
		return String(iso).toUpperCase().split('').map(function (letter) {
			return String.fromCodePoint(127397 + letter.charCodeAt(0));
		}).join('');
	}

	function findCountryByIso(iso) {
		var target = String(iso || '').toUpperCase();
		for (var i = 0; i < COUNTRIES.length; i += 1) {
			if (COUNTRIES[i].iso === target) {
				return COUNTRIES[i];
			}
		}
		return null;
	}

	function getFieldIdFromName(name) {
		var match = String(name || '').match(/^form_fields\[(.+?)\]$/);
		return match && match[1] ? match[1] : '';
	}

	function setHelperName(mainInput, helperInput, prefix) {
		if (!mainInput || !helperInput) {
			return;
		}
		var fieldId = getFieldIdFromName(mainInput.name);
		if (fieldId) {
			helperInput.name = prefix + '[' + fieldId + ']';
		}
	}

	function optionSearchText(country) {
		return normalizeSearch(country.name + ' ' + country.iso + ' ' + country.dial);
	}

	function createCountryOption(country) {
		return '<button type="button" class="ecmsf-option ecmsf-country-option" role="option" data-iso="' + escapeHtml(country.iso) + '" data-search="' + escapeHtml(optionSearchText(country)) + '" aria-selected="false">' +
			'<span class="ecmsf-flag" aria-hidden="true">' + escapeHtml(flagEmoji(country.iso)) + '</span>' +
			'<span class="ecmsf-option-name">' + escapeHtml(country.name) + '</span>' +
		'</button>';
	}

	function createMobileOption(country) {
		return '<button type="button" class="ecmsf-option ecmsf-mobile-option" role="option" data-iso="' + escapeHtml(country.iso) + '" data-search="' + escapeHtml(optionSearchText(country)) + '" aria-selected="false">' +
			'<span class="ecmsf-flag" aria-hidden="true">' + escapeHtml(flagEmoji(country.iso)) + '</span>' +
			'<span class="ecmsf-option-name">' + escapeHtml(country.name) + '</span>' +
			'<span class="ecmsf-option-dial">' + escapeHtml(country.dial) + '</span>' +
		'</button>';
	}

	function renderCountryOptions(field) {
		var optionsContainer = field.querySelector('[data-ecmsf-role="country-options"]');
		if (!optionsContainer || optionsContainer.dataset.ecmsfRendered === 'true') {
			return;
		}
		optionsContainer.innerHTML = COUNTRIES.map(createCountryOption).join('');
		optionsContainer.dataset.ecmsfRendered = 'true';
	}

	function renderMobileOptions(field) {
		var optionsContainer = field.querySelector('[data-ecmsf-role="mobile-options"]');
		if (!optionsContainer || optionsContainer.dataset.ecmsfRendered === 'true') {
			return;
		}
		optionsContainer.innerHTML = COUNTRIES.map(createMobileOption).join('');
		optionsContainer.dataset.ecmsfRendered = 'true';
	}

	function closePanels(exceptField) {
		document.querySelectorAll(COUNTRY_SELECTOR + '.is-open, ' + MOBILE_SELECTOR + '.is-open').forEach(function (field) {
			if (field === exceptField) {
				return;
			}
			field.classList.remove('is-open');
			field.querySelectorAll('[aria-expanded="true"]').forEach(function (trigger) {
				trigger.setAttribute('aria-expanded', 'false');
			});
		});
	}

	function openPanel(field, trigger, searchInput) {
		closePanels(field);
		field.classList.add('is-open');
		if (trigger) {
			trigger.setAttribute('aria-expanded', 'true');
		}
		window.setTimeout(function () {
			if (searchInput) {
				searchInput.focus();
			}
		}, 0);
	}

	function togglePanel(field, trigger, searchInput) {
		if (field.classList.contains('is-open')) {
			field.classList.remove('is-open');
			if (trigger) {
				trigger.setAttribute('aria-expanded', 'false');
			}
			return;
		}
		openPanel(field, trigger, searchInput);
	}

	function filterOptions(panel, searchInput) {
		if (!panel || !searchInput) {
			return;
		}
		var query = normalizeSearch(searchInput.value);
		panel.querySelectorAll('.ecmsf-option').forEach(function (option) {
			var haystack = normalizeSearch(option.getAttribute('data-search') || '');
			option.hidden = Boolean(query) && haystack.indexOf(query) === -1;
		});
	}

	function resetSearch(field) {
		var search = field.querySelector('.ecmsf-search-input');
		if (search) {
			search.value = '';
		}
		field.querySelectorAll('.ecmsf-option').forEach(function (option) {
			option.hidden = false;
		});
	}

	function bindSearchInput(search, panel) {
		if (!search || !panel || search.dataset.ecmsfSearchReady === 'true') {
			return;
		}

		search.dataset.ecmsfSearchReady = 'true';

		['input', 'keyup', 'change', 'search'].forEach(function (eventName) {
			search.addEventListener(eventName, function () {
				filterOptions(panel, search);
			});
		});

		search.addEventListener('click', function (event) {
			event.stopPropagation();
		});

		search.addEventListener('mousedown', function (event) {
			event.stopPropagation();
		});

		search.addEventListener('touchstart', function (event) {
			event.stopPropagation();
		}, { passive: true });

		search.addEventListener('keydown', function (event) {
			if (event.key !== 'Enter') {
				return;
			}

			event.preventDefault();
			var firstVisibleOption = Array.prototype.find.call(panel.querySelectorAll('.ecmsf-option'), function (option) {
				return !option.hidden;
			});

			if (firstVisibleOption) {
				firstVisibleOption.click();
			}
		});
	}

	function markSelectedOptions(field, iso) {
		field.querySelectorAll('.ecmsf-option').forEach(function (option) {
			var isSelected = option.getAttribute('data-iso') === iso;
			option.classList.toggle('is-selected', isSelected);
			option.setAttribute('aria-selected', isSelected ? 'true' : 'false');
		});
	}

	function countryDisplayValue(country) {
		return country ? String(flagEmoji(country.iso) + ' ' + country.name).trim() : '';
	}

	function mobileDisplayValue(country) {
		return country ? String(flagEmoji(country.iso) + ' ' + country.dial).trim() : '';
	}

	function dispatchInputEvents(input) {
		if (!input) {
			return;
		}
		input.dispatchEvent(new Event('input', { bubbles: true }));
		input.dispatchEvent(new Event('change', { bubbles: true }));
	}

	function syncMobileValue(field) {
		var submission = field.querySelector('[data-ecmsf-role="mobile-submission"]');
		var numberInput = field.querySelector('[data-ecmsf-role="mobile-number"]');
		var isoInput = field.querySelector('[data-ecmsf-role="mobile-iso"]');
		if (!submission || !numberInput || !isoInput) {
			return;
		}
		var country = findCountryByIso(isoInput.value);
		var number = String(numberInput.value || '').trim();
		var dial = country ? country.dial : '';
		submission.value = number ? String((dial ? dial + ' ' : '') + number).trim() : '';
		dispatchInputEvents(submission);
	}

	function setCountryField(field, iso, fromSync) {
		var country = findCountryByIso(iso);
		var submission = field.querySelector('[data-ecmsf-role="country-submission"]');
		var isoInput = field.querySelector('[data-ecmsf-role="country-iso"]');
		var display = field.querySelector('[data-ecmsf-role="country-display"]');
		if (!submission || !isoInput || !display) {
			return;
		}
		submission.value = country ? country.name : '';
		isoInput.value = country ? country.iso : '';
		display.value = countryDisplayValue(country);
		markSelectedOptions(field, country ? country.iso : '');
		dispatchInputEvents(submission);
		if (!fromSync && country) {
			syncMobilesInForm(field.closest('form'), country.iso);
		}
	}

	function setMobileFieldCountry(field, iso, fromSync) {
		var country = findCountryByIso(iso);
		var isoInput = field.querySelector('[data-ecmsf-role="mobile-iso"]');
		var display = field.querySelector('[data-ecmsf-role="mobile-display"]');
		if (!isoInput || !display) {
			return;
		}
		isoInput.value = country ? country.iso : '';
		display.value = mobileDisplayValue(country);
		markSelectedOptions(field, country ? country.iso : '');
		syncMobileValue(field);
		if (!fromSync && country) {
			syncCountriesInForm(field.closest('form'), country.iso);
		}
	}

	function syncMobilesInForm(form, iso) {
		if (!form) {
			return;
		}
		form.querySelectorAll(MOBILE_SELECTOR).forEach(function (field) {
			setMobileFieldCountry(field, iso, true);
		});
	}

	function syncCountriesInForm(form, iso) {
		if (!form) {
			return;
		}
		form.querySelectorAll(COUNTRY_SELECTOR).forEach(function (field) {
			setCountryField(field, iso, true);
		});
	}

	function focusSearchWithTypedKey(field, display, panel, search, event) {
		if (!search || !event || event.ctrlKey || event.metaKey || event.altKey) {
			return false;
		}
		if (event.key && event.key.length === 1) {
			openPanel(field, display, search);
			search.value = event.key;
			filterOptions(panel, search);
			event.preventDefault();
			return true;
		}
		return false;
	}

	function bindDisplayKeyboard(field, display, panel, search) {
		if (!display) {
			return;
		}
		display.addEventListener('keydown', function (event) {
			if (focusSearchWithTypedKey(field, display, panel, search, event)) {
				return;
			}
			if (event.key === 'Enter' || event.key === ' ' || event.key === 'ArrowDown') {
				event.preventDefault();
				openPanel(field, display, search);
			}
		});
	}

	function initCountryField(field) {
		if (!field || field.dataset.ecmsfReady === 'true') {
			return;
		}
		renderCountryOptions(field);

		var display = field.querySelector('[data-ecmsf-role="country-display"]');
		var panel = field.querySelector('[data-ecmsf-role="country-panel"]');
		var search = field.querySelector('[data-ecmsf-role="country-search"]');
		var submission = field.querySelector('[data-ecmsf-role="country-submission"]');
		var isoInput = field.querySelector('[data-ecmsf-role="country-iso"]');

		if (!display || !panel || !submission || !isoInput) {
			return;
		}

		field.dataset.ecmsfReady = 'true';
		setHelperName(submission, isoInput, 'ecmsf_country_iso');

		display.addEventListener('click', function () {
			resetSearch(field);
			togglePanel(field, display, search);
		});
		bindDisplayKeyboard(field, display, panel, search);

		bindSearchInput(search, panel);

		panel.addEventListener('click', function (event) {
			var option = event.target.closest('.ecmsf-country-option');
			if (!option) {
				return;
			}
			setCountryField(field, option.getAttribute('data-iso'), false);
			field.classList.remove('is-open');
			display.setAttribute('aria-expanded', 'false');
			display.focus();
		});

		var form = field.closest('form');
		if (form) {
			form.addEventListener('reset', function () {
				window.setTimeout(function () {
					setCountryField(field, '', true);
					resetSearch(field);
				}, 0);
			});
		}
	}

	function initMobileField(field) {
		if (!field || field.dataset.ecmsfReady === 'true') {
			return;
		}
		renderMobileOptions(field);

		var display = field.querySelector('[data-ecmsf-role="mobile-display"]');
		var panel = field.querySelector('[data-ecmsf-role="mobile-panel"]');
		var search = field.querySelector('[data-ecmsf-role="mobile-search"]');
		var submission = field.querySelector('[data-ecmsf-role="mobile-submission"]');
		var isoInput = field.querySelector('[data-ecmsf-role="mobile-iso"]');
		var numberInput = field.querySelector('[data-ecmsf-role="mobile-number"]');

		if (!display || !panel || !submission || !isoInput || !numberInput) {
			return;
		}

		field.dataset.ecmsfReady = 'true';
		setHelperName(submission, isoInput, 'ecmsf_mobile_iso');

		display.addEventListener('click', function () {
			resetSearch(field);
			togglePanel(field, display, search);
		});
		bindDisplayKeyboard(field, display, panel, search);

		bindSearchInput(search, panel);

		panel.addEventListener('click', function (event) {
			var option = event.target.closest('.ecmsf-mobile-option');
			if (!option) {
				return;
			}
			setMobileFieldCountry(field, option.getAttribute('data-iso'), false);
			field.classList.remove('is-open');
			display.setAttribute('aria-expanded', 'false');
			display.focus();
		});

		numberInput.addEventListener('input', function () {
			syncMobileValue(field);
		});

		var form = field.closest('form');
		if (form) {
			form.addEventListener('reset', function () {
				window.setTimeout(function () {
					setMobileFieldCountry(field, '', true);
					numberInput.value = '';
					syncMobileValue(field);
					resetSearch(field);
				}, 0);
			});

			var firstCountry = form.querySelector(COUNTRY_SELECTOR + ' [data-ecmsf-role="country-iso"]');
			if (firstCountry && firstCountry.value) {
				setMobileFieldCountry(field, firstCountry.value, true);
			}
		}
	}

	function initWithin(scope) {
		(scope || document).querySelectorAll(COUNTRY_SELECTOR).forEach(initCountryField);
		(scope || document).querySelectorAll(MOBILE_SELECTOR).forEach(initMobileField);
	}

	document.addEventListener('DOMContentLoaded', function () {
		initWithin(document);
	});

	document.addEventListener('click', function (event) {
		if (!event.target.closest(COUNTRY_SELECTOR) && !event.target.closest(MOBILE_SELECTOR)) {
			closePanels(null);
		}
	});

	document.addEventListener('keydown', function (event) {
		if (event.key === 'Escape') {
			closePanels(null);
		}
	});

	window.addEventListener('elementor/frontend/init', function () {
		if (!window.elementorFrontend || !window.elementorFrontend.hooks) {
			return;
		}
		window.elementorFrontend.hooks.addAction('frontend/element_ready/form.default', function ($scope) {
			var root = $scope && $scope[0] ? $scope[0] : document;
			initWithin(root);
		});
	});
})();
