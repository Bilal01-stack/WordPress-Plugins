=== Elementor Country Dropdown + Mobile Sync Fields ===
Contributors: morosoft
Tags: elementor, form, country, mobile, phone, dropdown
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.3.2
License: GPLv2 or later

Adds two Elementor Pro Form field types:
1) Country Dropdown
2) Mobile Number + Country Code

Version 1.3.2 fixes:
- Search results now visually hide correctly while typing.
- Everything else remains the same as v1.3.1: default Elementor styling, field sync, and validation.
