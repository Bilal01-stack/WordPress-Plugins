<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor Pro form field: Mobile Number + Country Code.
 */
class ECMSF_Mobile_Field extends \ElementorPro\Modules\Forms\Fields\Field_Base {

	/**
	 * Compatibility for Elementor versions that use dependency properties.
	 *
	 * @var array
	 */
	public $depended_scripts = [ 'ecmsf-fields' ];

	/**
	 * Compatibility for Elementor versions that use dependency properties.
	 *
	 * @var array
	 */
	public $depended_styles = [ 'ecmsf-fields' ];

	public function get_type(): string {
		return 'ecmsf-mobile-country-code';
	}

	public function get_name(): string {
		return esc_html__( 'Mobile Number + Country Code', 'elementor-country-dropdown-field' );
	}

	public function get_script_depends(): array {
		return [ 'ecmsf-fields' ];
	}

	public function get_style_depends(): array {
		return [ 'ecmsf-fields' ];
	}

	/**
	 * Render field output.
	 *
	 * @param array $item Field settings.
	 * @param int   $item_index Field index.
	 * @param mixed $form Elementor form widget.
	 */
	public function render( $item, $item_index, $form ): void {
		$placeholder = ! empty( $item['placeholder'] )
			? (string) $item['placeholder']
			: esc_html__( 'Mobile Number', 'elementor-country-dropdown-field' );

		$required = ! empty( $item['required'] );

		// Elementor prepares the original field input attributes on "input{$index}".
		// We keep those attributes for form submission, but force the control to stay hidden.
		if ( method_exists( $form, 'remove_render_attribute' ) ) {
			$form->remove_render_attribute( 'input' . $item_index, 'type' );
		}

		$form->add_render_attribute(
			'input' . $item_index,
			[
				'type'            => 'hidden',
				'hidden'          => 'hidden',
				'style'           => 'display:none !important;',
				'class'           => [ 'ecmsf-hidden-input', 'ecmsf-mobile-submission' ],
				'data-ecmsf-role' => 'mobile-submission',
			]
		);

		$form->add_render_attribute(
			'ecmsf_mobile_code_display_' . $item_index,
			[
				'type'            => 'text',
				'readonly'        => 'readonly',
				'autocomplete'    => 'off',
				'placeholder'     => esc_html__( 'Code', 'elementor-country-dropdown-field' ),
				'class'           => [ 'ecmsf-display-input', 'ecmsf-mobile-code-display', 'elementor-field', 'elementor-field-textual' ],
				'data-ecmsf-role' => 'mobile-display',
				'aria-haspopup'   => 'listbox',
				'aria-expanded'   => 'false',
			]
		);

		$form->add_render_attribute(
			'ecmsf_mobile_number_' . $item_index,
			[
				'type'            => 'tel',
				'inputmode'       => 'tel',
				'autocomplete'    => 'tel-national',
				'placeholder'     => $placeholder,
				'class'           => [ 'ecmsf-mobile-number', 'elementor-field', 'elementor-field-textual' ],
				'data-ecmsf-role' => 'mobile-number',
			]
		);

		if ( $required ) {
			$form->add_render_attribute(
				'ecmsf_mobile_code_display_' . $item_index,
				'aria-required',
				'true'
			);

			$form->add_render_attribute(
				'ecmsf_mobile_number_' . $item_index,
				[
					'required'      => 'required',
					'aria-required' => 'true',
				]
			);
		}

		echo '<div class="ecmsf-mobile-field" data-ecmsf-mobile-field>';
		echo '<input ' . $form->get_render_attribute_string( 'input' . $item_index ) . '>';
		echo '<input type="hidden" hidden class="ecmsf-hidden-input" style="display:none !important;" data-ecmsf-role="mobile-iso" value="">';

		echo '<div class="ecmsf-mobile-control">';
		echo '<div class="ecmsf-mobile-picker">';
		echo '<div class="ecmsf-display-shell">';
		echo '<input ' . $form->get_render_attribute_string( 'ecmsf_mobile_code_display_' . $item_index ) . '>';
		echo '<span class="ecmsf-chevron" aria-hidden="true"></span>';
		echo '</div>';

		echo '<div class="ecmsf-panel ecmsf-mobile-panel" data-ecmsf-role="mobile-panel" role="listbox" tabindex="-1">';
		echo '<div class="ecmsf-search-wrap">';
		echo '<input type="search" class="ecmsf-search-input elementor-field elementor-field-textual" data-ecmsf-role="mobile-search" placeholder="' . esc_attr__( 'Search country or code...', 'elementor-country-dropdown-field' ) . '" autocomplete="off" aria-label="' . esc_attr__( 'Search country or code', 'elementor-country-dropdown-field' ) . '">';
		echo '</div>';
		echo '<div class="ecmsf-options" data-ecmsf-role="mobile-options"></div>';
		echo '</div>';
		echo '</div>';

		echo '<input ' . $form->get_render_attribute_string( 'ecmsf_mobile_number_' . $item_index ) . '>';
		echo '</div>';
		echo '</div>';
	}

	/**
	 * Validate field submission and force the mobile country to match the country field.
	 *
	 * @param array $field Submitted field data.
	 * @param mixed $record Elementor record.
	 * @param mixed $ajax_handler Elementor Ajax handler.
	 */
	public function validation( $field, $record, $ajax_handler ): void {
		$value = isset( $field['value'] ) ? trim( (string) $field['value'] ) : '';

		if ( ! empty( $field['required'] ) && '' === $value ) {
			$ajax_handler->add_error(
				$field['id'],
				esc_html__( 'Please enter your mobile number.', 'elementor-country-dropdown-field' )
			);
			return;
		}

		if ( '' === $value ) {
			return;
		}

		$digits_only = preg_replace( '/\D+/', '', $value );
		if ( strlen( (string) $digits_only ) < 5 ) {
			$ajax_handler->add_error(
				$field['id'],
				esc_html__( 'Please enter a valid mobile number.', 'elementor-country-dropdown-field' )
			);
			return;
		}

		$mobile_iso = $this->get_posted_iso_for_field( 'ecmsf_mobile_iso', (string) $field['id'] );
		if ( '' === $mobile_iso ) {
			$ajax_handler->add_error(
				$field['id'],
				esc_html__( 'Please select the mobile country code.', 'elementor-country-dropdown-field' )
			);
			return;
		}

		$posted_country_isos = $this->get_posted_iso_group( 'ecmsf_country_iso' );
		foreach ( $posted_country_isos as $country_iso ) {
			if ( '' !== $country_iso && $country_iso !== $mobile_iso ) {
				$ajax_handler->add_error(
					$field['id'],
					esc_html__( 'The selected country and the mobile country code must match.', 'elementor-country-dropdown-field' )
				);
				return;
			}
		}
	}

	/**
	 * Get a posted ISO value by field ID.
	 *
	 * @param string $group_name POST group name.
	 * @param string $field_id Elementor field ID.
	 * @return string
	 */
	private function get_posted_iso_for_field( $group_name, $field_id ) {
		if ( ! isset( $_POST[ $group_name ] ) || ! is_array( $_POST[ $group_name ] ) ) {
			return '';
		}

		$group = wp_unslash( $_POST[ $group_name ] );

		if ( ! isset( $group[ $field_id ] ) ) {
			return '';
		}

		$iso = strtoupper( sanitize_text_field( (string) $group[ $field_id ] ) );

		return preg_match( '/^[A-Z]{2}$/', $iso ) ? $iso : '';
	}

	/**
	 * Get all posted ISO values from a helper POST group.
	 *
	 * @param string $group_name POST group name.
	 * @return array
	 */
	private function get_posted_iso_group( $group_name ) {
		if ( ! isset( $_POST[ $group_name ] ) || ! is_array( $_POST[ $group_name ] ) ) {
			return [];
		}

		$group  = wp_unslash( $_POST[ $group_name ] );
		$result = [];

		foreach ( $group as $iso ) {
			$iso = strtoupper( sanitize_text_field( (string) $iso ) );

			if ( preg_match( '/^[A-Z]{2}$/', $iso ) ) {
				$result[] = $iso;
			}
		}

		return $result;
	}
}
