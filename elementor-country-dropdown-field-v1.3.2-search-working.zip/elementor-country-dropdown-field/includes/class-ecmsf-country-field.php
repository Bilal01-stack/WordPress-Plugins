<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor Pro form field: Searchable Country Dropdown.
 */
class ECMSF_Country_Field extends \ElementorPro\Modules\Forms\Fields\Field_Base {

	/**
	 * Compatibility for Elementor versions that use dependency properties.
	 *
	 * @var array
	 */
	public $depended_scripts = [ 'ecmsf-fields' ];

	/**
	 * Compatibility for Elementor versions that use dependency properties.
	 *
	 * @var array
	 */
	public $depended_styles = [ 'ecmsf-fields' ];

	public function get_type(): string {
		return 'ecmsf-country-dropdown';
	}

	public function get_name(): string {
		return esc_html__( 'Country Dropdown', 'elementor-country-dropdown-field' );
	}

	public function get_script_depends(): array {
		return [ 'ecmsf-fields' ];
	}

	public function get_style_depends(): array {
		return [ 'ecmsf-fields' ];
	}

	/**
	 * Render field output.
	 *
	 * @param array $item Field settings.
	 * @param int   $item_index Field index.
	 * @param mixed $form Elementor form widget.
	 */
	public function render( $item, $item_index, $form ): void {
		$placeholder = ! empty( $item['placeholder'] )
			? (string) $item['placeholder']
			: esc_html__( 'Select Country', 'elementor-country-dropdown-field' );

		$required = ! empty( $item['required'] );

		// Elementor prepares the original field input attributes on "input{$index}".
		// We keep those attributes for form submission, but force the control to stay hidden.
		if ( method_exists( $form, 'remove_render_attribute' ) ) {
			$form->remove_render_attribute( 'input' . $item_index, 'type' );
		}

		$form->add_render_attribute(
			'input' . $item_index,
			[
				'type'            => 'hidden',
				'hidden'          => 'hidden',
				'style'           => 'display:none !important;',
				'class'           => [ 'ecmsf-hidden-input', 'ecmsf-country-submission' ],
				'data-ecmsf-role' => 'country-submission',
			]
		);

		$form->add_render_attribute(
			'ecmsf_country_display_' . $item_index,
			[
				'type'            => 'text',
				'readonly'        => 'readonly',
				'autocomplete'    => 'off',
				'placeholder'     => $placeholder,
				'class'           => [ 'ecmsf-display-input', 'ecmsf-country-display', 'elementor-field', 'elementor-field-textual' ],
				'data-ecmsf-role' => 'country-display',
				'aria-haspopup'   => 'listbox',
				'aria-expanded'   => 'false',
			]
		);

		if ( $required ) {
			$form->add_render_attribute(
				'ecmsf_country_display_' . $item_index,
				'aria-required',
				'true'
			);
		}

		echo '<div class="ecmsf-country-field" data-ecmsf-country-field data-placeholder="' . esc_attr( $placeholder ) . '">';
		echo '<input ' . $form->get_render_attribute_string( 'input' . $item_index ) . '>';
		echo '<input type="hidden" hidden class="ecmsf-hidden-input" style="display:none !important;" data-ecmsf-role="country-iso" value="">';

		echo '<div class="ecmsf-display-shell">';
		echo '<input ' . $form->get_render_attribute_string( 'ecmsf_country_display_' . $item_index ) . '>';
		echo '<span class="ecmsf-chevron" aria-hidden="true"></span>';
		echo '</div>';

		echo '<div class="ecmsf-panel" data-ecmsf-role="country-panel" role="listbox" tabindex="-1">';
		echo '<div class="ecmsf-search-wrap">';
		echo '<input type="search" class="ecmsf-search-input elementor-field elementor-field-textual" data-ecmsf-role="country-search" placeholder="' . esc_attr__( 'Search country...', 'elementor-country-dropdown-field' ) . '" autocomplete="off" aria-label="' . esc_attr__( 'Search country', 'elementor-country-dropdown-field' ) . '">';
		echo '</div>';
		echo '<div class="ecmsf-options" data-ecmsf-role="country-options"></div>';
		echo '</div>';
		echo '</div>';
	}

	/**
	 * Validate field submission.
	 *
	 * @param array $field Submitted field data.
	 * @param mixed $record Elementor record.
	 * @param mixed $ajax_handler Elementor Ajax handler.
	 */
	public function validation( $field, $record, $ajax_handler ): void {
		$value = isset( $field['value'] ) ? trim( (string) $field['value'] ) : '';

		if ( ! empty( $field['required'] ) && '' === $value ) {
			$ajax_handler->add_error(
				$field['id'],
				esc_html__( 'Please select a country.', 'elementor-country-dropdown-field' )
			);
		}
	}
}
